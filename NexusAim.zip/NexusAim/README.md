# Nexus Aim — Mira flutuante e sensibilidade para Free Fire

## Como gerar o APK pelo GitHub
1. Crie um repositório novo no GitHub.
2. Envie TODO o conteúdo deste ZIP (incluindo a pasta oculta `.github`).
3. Vá na aba **Actions** › "Build APK" (roda sozinho a cada push, ou clique em *Run workflow*).
4. Quando terminar (~5 min), abra a execução e baixe o artefato **NexusAim-APK**.
5. Instale o `app-debug.apk` no celular (permita "instalar apps desconhecidos").

## Recursos
- Aba **Auxílio de Mira**: 8 estilos de mira, 8 cores, tamanho/espessura/opacidade, brilho neon e pré-visualização.
- **Painel flutuante** (bolha arrastável): MIRA · MODOS (6 presets + filtros de tela) · OTIMIZAR (monitor de RAM/bateria/temperatura, liberar RAM, modo foco) · SENS.
- Aba **Sensibilidade**: busca entre 895 celulares (2017–2026), filtro por marca e modo manual.
- Botão **JOGAR FREE FIRE**: abre o Free Fire / FF MAX direto do app, já com a mira e o painel ativos.
- Aba **Treino**: treino de capa com alvos em movimento que mede se você passa do alvo ou fica curto e recalibra sua sensibilidade salva.
- Pede a permissão "Sobrepor a outros apps" ao abrir.
