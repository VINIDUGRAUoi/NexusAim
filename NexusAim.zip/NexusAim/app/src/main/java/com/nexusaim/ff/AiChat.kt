package com.nexusaim.ff

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.roundToInt

/**
 * NEXUS IA — assistente offline de sensibilidade e jogabilidade.
 * Entende o que o jogador escreve (PT/EN/ES), cria sensibilidade
 * personalizada por perguntas e ajusta a sensibilidade conforme as queixas.
 */
class NexusBrain(private val ctx: Context, private val prefs: Prefs) {

    sealed class Reply {
        data class Text(val text: String) : Reply()
        data class Choices(val text: String, val options: List<String>) : Reply()
        data class Sens(val text: String, val result: SensResult) : Reply()
    }

    private enum class Step { NONE, PHONE, STYLE, FINGERS }

    private var step = Step.NONE
    private var phone: Phone? = null
    private var genericTier = 0
    private var style = 1           // 0 rush, 1 equilibrado, 2 sniper
    private var last: SensResult? = null

    private val lang = ctx.resources.configuration.locales[0].language
    private fun t(pt: String, en: String, es: String) = when (lang) { "en" -> en; "es" -> es; else -> pt }

    // ------------------------------------------------------------------ chips
    val quickChips: List<String> get() = listOf(
        t("⚡ Criar minha sensi", "⚡ Create my sens", "⚡ Crear mi sensi"),
        t("⬆ Mira passa da cabeça", "⬆ Aim goes over the head", "⬆ La mira pasa la cabeza"),
        t("⬇ Mira não sobe", "⬇ Aim doesn't go up", "⬇ La mira no sube"),
        t("🎯 Dicas de capa", "🎯 Headshot tips", "🎯 Consejos de tiro a la cabeza"),
        t("✋ Melhor HUD", "✋ Best HUD", "✋ Mejor HUD"),
        t("🐢 Celular travando", "🐢 Phone lagging", "🐢 Celular con lag"),
        t("🏋 Como treinar", "🏋 How to train", "🏋 Cómo entrenar")
    )

    private val styleOptions get() = listOf(
        t("🔥 Rush (perto)", "🔥 Rush (close)", "🔥 Rush (cerca)"),
        t("⚖ Equilibrado", "⚖ Balanced", "⚖ Equilibrado"),
        t("🎯 Sniper (longe)", "🎯 Sniper (long)", "🎯 Francotirador (lejos)")
    )
    private val fingerOptions get() = listOf(
        t("2 dedos", "2 fingers", "2 dedos"),
        t("3 dedos", "3 fingers", "3 dedos"),
        t("4 dedos ou mais", "4+ fingers", "4 dedos o más")
    )
    private val tierOptions get() = (1..4).map { Catalog.tierName(ctx, it) }

    fun greet(): List<Reply> = listOf(
        Reply.Text(t(
            "Fala, jogador! 👋 Eu sou a NEXUS IA.\nPosso criar uma sensibilidade só sua, ajustar a que você já usa e dar dicas de capa, HUD e desempenho.",
            "Hey, player! 👋 I'm NEXUS AI.\nI can create a sensitivity just for you, tune the one you use and give headshot, HUD and performance tips.",
            "¡Hola, jugador! 👋 Soy NEXUS IA.\nPuedo crear una sensibilidad solo para ti, ajustar la que usas y darte consejos de tiros a la cabeza, HUD y rendimiento.")),
        Reply.Choices(t("Por onde começamos?", "Where do we start?", "¿Por dónde empezamos?"), quickChips.take(4))
    )

    // ------------------------------------------------------------------ entrada
    fun handle(raw: String): List<Reply> {
        val q = PhoneDb.normalize(raw)
        if (q.isBlank()) return emptyList()

        if (has(q, "xit", "hack", "cheat", "aimbot", "regedit", "trapaca", "trampa", "auto mira", "headtrick", "mod menu")) {
            step = Step.NONE
            return listOf(Reply.Text(t(
                "Xit, regedit e aimbot eu não recomendo de jeito nenhum: o anti-cheat da Garena detecta e bane a conta (às vezes o aparelho). 🚫\nO que dá capa de verdade e sem risco é sensibilidade certa + mira na altura certa + treino. Quer que eu crie sua sensi?",
                "I don't recommend cheats, regedit or aimbots at all: Garena's anti-cheat detects them and bans the account (sometimes the device). 🚫\nWhat really gives headshots, with no risk, is the right sensitivity + right crosshair height + practice. Want me to create your sens?",
                "No recomiendo hacks, regedit ni aimbot: el anti-cheat de Garena los detecta y banea la cuenta (a veces el dispositivo). 🚫\nLo que da tiros a la cabeza de verdad y sin riesgo es la sensibilidad correcta + la altura de mira correcta + práctica. ¿Creo tu sensi?")),
                Reply.Choices("", listOf(quickChips[0])))
        }
        if (has(q, "cancelar", "cancel", "parar", "stop", "esquece", "olvida")) {
            step = Step.NONE
            return listOf(Reply.Choices(t("Beleza, cancelei. O que mais posso fazer?", "Ok, cancelled. What else can I do?", "Listo, cancelado. ¿Qué más puedo hacer?"), quickChips.take(4)))
        }

        // queixas de mira → ajuste
        adjustment(q)?.let { return it }

        // fluxo de criação em andamento
        when (step) {
            Step.PHONE -> return onPhoneAnswer(raw, q)
            Step.STYLE -> return onStyleAnswer(q)
            Step.FINGERS -> return onFingersAnswer(q)
            Step.NONE -> {}
        }

        // pediu sensi (com ou sem celular na frase)
        val found = findPhone(q)
        if (found != null || has(q, "sensi", "sens ", "sensibilidad", "sensitivity", "criar", "crear", "create", "gerar", "generar", "configurar")) {
            if (found != null) { phone = found; genericTier = 0; return askStyle(found.fullName) }
            step = Step.PHONE
            return listOf(Reply.Text(t(
                "Bora! 📱 Qual é o seu celular? (ex: Redmi Note 13, Galaxy A15, iPhone 13)",
                "Let's go! 📱 What's your phone? (e.g. Redmi Note 13, Galaxy A15, iPhone 13)",
                "¡Vamos! 📱 ¿Cuál es tu celular? (ej: Redmi Note 13, Galaxy A15, iPhone 13)")))
        }

        return topic(q)
    }

    // ------------------------------------------------------------------ criação
    private fun onPhoneAnswer(raw: String, q: String): List<Reply> {
        val tierIdx = tierOptions.indexOfFirst { PhoneDb.normalize(it) == q }
        if (tierIdx >= 0) {
            phone = null; genericTier = tierIdx + 1
            return askStyle(tierOptions[tierIdx])
        }
        val found = findPhone(q)
        if (found != null) { phone = found; genericTier = 0; return askStyle(found.fullName) }

        val suggestions = PhoneDb.search(ctx, raw, null).take(3)
        if (suggestions.isNotEmpty()) {
            return listOf(Reply.Choices(t("Achei estes parecidos. É algum deles?", "I found these similar ones. Is it one of them?", "Encontré estos parecidos. ¿Es alguno?"),
                suggestions.map { it.fullName }))
        }
        return listOf(Reply.Choices(t(
            "Não achei esse modelo na minha base. 🤔 Sem problema: como é o desempenho do seu celular?",
            "I couldn't find that model. 🤔 No problem: how powerful is your phone?",
            "No encontré ese modelo. 🤔 Sin problema: ¿qué tal es el rendimiento de tu celular?"), tierOptions))
    }

    private fun askStyle(name: String): List<Reply> {
        step = Step.STYLE
        return listOf(Reply.Choices(t(
            "✔ $name anotado! Qual é o seu estilo de jogo?",
            "✔ $name noted! What's your play style?",
            "✔ ¡$name anotado! ¿Cuál es tu estilo de juego?"), styleOptions))
    }

    private fun onStyleAnswer(q: String): List<Reply> {
        style = when {
            has(q, "rush", "perto", "close", "cerca", "agress", "agres", "1x4", "x1") -> 0
            has(q, "sniper", "longe", "long", "lejos", "awm", "francotirador", "m82") -> 2
            has(q, "equilib", "balanc", "misto", "mixed", "mixto", "normal") -> 1
            else -> return listOf(Reply.Choices(t("Escolhe uma opção:", "Pick one:", "Elige una opción:"), styleOptions))
        }
        step = Step.FINGERS
        return listOf(Reply.Choices(t("E você joga com quantos dedos?", "And how many fingers do you play with?", "¿Y con cuántos dedos juegas?"), fingerOptions))
    }

    private fun onFingersAnswer(q: String): List<Reply> {
        val fingers = when {
            has(q, "4", "5", "6", "quatro", "four", "cuatro", "mais", "more", "garra", "claw") -> 4
            has(q, "3", "tres", "three") -> 3
            has(q, "2", "dois", "two", "dos") -> 2
            else -> return listOf(Reply.Choices(t("Escolhe uma opção:", "Pick one:", "Elige una opción:"), fingerOptions))
        }
        step = Step.NONE
        val base = phone?.let { SensitivityCalculator.calc(ctx, it) } ?: run {
            val tier = genericTier.coerceIn(1, 4)
            val hz = when (tier) { 1 -> 60; 2 -> 90; else -> 120 }
            SensitivityCalculator.calc(ctx, Catalog.tierName(ctx, tier), tier, hz, 6.6, 2023, false,
                "6.6\" · ${hz}Hz · ${Catalog.tierName(ctx, tier)}")
        }
        var g = base.geral; var rd = base.redDot; var x2 = base.x2; var x4 = base.x4; var awm = base.awm
        when (style) {
            0 -> { g += 5; rd += 5; x2 += 3 }
            2 -> { g -= 3; x4 -= 8; awm -= 10 }
        }
        when (fingers) {
            2 -> { g += 4; rd += 3 }
            4 -> { g -= 4; rd -= 3; x2 -= 2 }
        }
        val styleName = styleOptions[style].substringAfter(" ")
        val fingerName = fingerOptions[if (fingers == 2) 0 else if (fingers == 3) 1 else 2]
        val r = base.copy(
            title = "${base.title} · IA",
            specs = "${base.specs} · $styleName · $fingerName",
            geral = c(g), redDot = c(rd), x2 = c(x2), x4 = c(x4), awm = c(awm, 40)
        )
        last = r
        val why = when (style) {
            0 -> t("Deixei Geral e Ponto Vermelho mais altos para virar rápido na trocação de perto.",
                "I raised General and Red Dot so you can turn fast in close fights.",
                "Subí General y Punto Rojo para girar rápido en peleas cercanas.")
            2 -> t("Baixei 4x e AWM para a mira ficar firme nos tiros de longe.",
                "I lowered 4x and AWM so your aim stays steady on long shots.",
                "Bajé 4x y AWM para que la mira quede firme en tiros lejanos.")
            else -> t("Mantive tudo equilibrado para perto e longe.", "I kept everything balanced for close and long range.", "Mantuve todo equilibrado para cerca y lejos.")
        }
        return listOf(
            Reply.Sens(t("Pronto! ⚡ Aqui está a sua sensibilidade personalizada.\n$why",
                "Done! ⚡ Here is your personalized sensitivity.\n$why",
                "¡Listo! ⚡ Aquí está tu sensibilidad personalizada.\n$why"), r),
            Reply.Choices(t(
                "Coloque em Configurações › Sensibilidade no Free Fire e jogue umas partidas. Depois me conta: a mira passou da cabeça ou não subiu?",
                "Put it in Settings › Sensitivity in Free Fire and play a few matches. Then tell me: did the aim go over the head or not go up enough?",
                "Ponla en Ajustes › Sensibilidad en Free Fire y juega unas partidas. Luego dime: ¿la mira pasó la cabeza o no subió?"),
                listOf(quickChips[1], quickChips[2]))
        )
    }

    // ------------------------------------------------------------------ ajustes
    private fun adjustment(q: String): List<Reply>? {
        val tooHigh = has(q, "passa da", "passa do", "passa a cabeca", "passando", "passou", "muito rapid", "tremendo", "treme", "descontrol", "sensivel demais",
            "goes over", "too fast", "shaky", "overshoot", "pasa la cabeza", "pasa de la", "muy rapid", "tiembla", "se pasa")
        val tooLow = has(q, "nao sobe", "nao puxa", "fica embaixo", "fica no peito", "curta", "pesad", "lenta", "devagar", "nao chega",
            "doesn't go up", "doesnt go up", "not go up", "too slow", "chest", "heavy", "no sube", "se queda", "pecho", "muy lent")
        if (!tooHigh && !tooLow) return null

        val base = last ?: SensResult.fromJson(prefs.sensJson)
        if (base == null) {
            step = Step.PHONE
            return listOf(Reply.Text(t(
                "Para ajustar eu preciso saber sua sensi atual. Vamos criar uma primeiro: qual é o seu celular? 📱",
                "To tune it I need your current sens. Let's create one first: what's your phone? 📱",
                "Para ajustarla necesito tu sensi actual. Creemos una primero: ¿cuál es tu celular? 📱")))
        }
        val scope = has(q, "awm", "sniper", "4x", "mira 4", "scope", "francotirador", "m82")
        val f = if (tooHigh) 0.93 else 1.07
        fun m(v: Int, min: Int = 1) = c((v * f).roundToInt(), min)
        val r = if (scope) base.copy(x4 = m(base.x4), awm = m(base.awm, 40))
        else base.copy(geral = m(base.geral), redDot = m(base.redDot), x2 = m(base.x2), x4 = m(base.x4))
        last = r.copy(title = if (r.title.contains("✎")) r.title else "${r.title} ✎")
        val msg = if (tooHigh) t(
            "Entendi: a mira está passando do alvo, então a sensi está alta. Baixei 7%${if (scope) " nas miras de longe" else ""}. 👇\nDica: puxe a mira só até o pescoço do inimigo, o recuo leva até a cabeça.",
            "Got it: your aim overshoots, so the sens is too high. I lowered it 7%${if (scope) " on long-range scopes" else ""}. 👇\nTip: drag only up to the enemy's neck, the recoil takes it to the head.",
            "Entendido: la mira se pasa, así que la sensi está alta. La bajé 7%${if (scope) " en las miras de lejos" else ""}. 👇\nConsejo: sube la mira solo hasta el cuello, el retroceso la lleva a la cabeza.")
        else t(
            "Entendi: a mira está ficando no peito, então a sensi está baixa. Aumentei 7%${if (scope) " nas miras de longe" else ""}. 👇\nDica: comece a puxar para cima logo no primeiro tiro, num movimento só.",
            "Got it: your aim stays at the chest, so the sens is too low. I raised it 7%${if (scope) " on long-range scopes" else ""}. 👇\nTip: start dragging up right on the first shot, in one motion.",
            "Entendido: la mira se queda en el pecho, así que la sensi está baja. La subí 7%${if (scope) " en las miras de lejos" else ""}. 👇\nConsejo: empieza a subir desde el primer disparo, en un solo movimiento.")
        return listOf(Reply.Sens(msg, last!!))
    }

    // ------------------------------------------------------------------ assuntos
    private fun topic(q: String): List<Reply> {
        val text = when {
            has(q, "capa", "cabeca", "headshot", "hs", "capar", "head", "cabeza", "acertar", "mirar") -> t(
                "🎯 Segredos da capa:\n• Deixe a mira sempre na altura da cabeça enquanto anda (não olhe pro chão).\n• Na trocação, mire no peito e puxe para cima num movimento só no 1º tiro.\n• Agache e atire: o inimigo erra mais e sua mira fica firme.\n• Use a mira Precisão (ponto pequeno) no painel flutuante.\n• Se passar da cabeça ou ficar no peito, me fala que eu ajusto sua sensi.",
                "🎯 Headshot secrets:\n• Keep your crosshair at head height while moving (don't look at the floor).\n• In fights, aim at the chest and drag up in one motion on the 1st shot.\n• Crouch while shooting: the enemy misses more and your aim stays steady.\n• Use the Precision crosshair (small dot) in the floating panel.\n• If you overshoot or stay at the chest, tell me and I'll tune your sens.",
                "🎯 Secretos del tiro a la cabeza:\n• Mantén la mira a la altura de la cabeza al moverte (no mires al suelo).\n• En peleas, apunta al pecho y sube en un solo movimiento en el 1er disparo.\n• Agáchate al disparar: el enemigo falla más y tu mira queda firme.\n• Usa la mira Precisión (punto pequeño) del panel flotante.\n• Si te pasas o te quedas en el pecho, dime y ajusto tu sensi.")
            has(q, "hud", "dedo", "dedos", "finger", "layout", "botoes", "botones", "garra", "claw") -> t(
                "✋ HUD:\n• 2 dedos: mais fácil de aprender, bom para começar.\n• 3 dedos: indicador esquerdo no tiro, dá para mirar e atirar juntos.\n• 4 dedos (garra): pular/agachar enquanto mira, melhor para competitivo.\nDeixe o botão de tiro onde o dedo cai natural e não muito grande (45–60%).",
                "✋ HUD:\n• 2 fingers: easiest to learn, good to start.\n• 3 fingers: left index on fire, aim and shoot at the same time.\n• 4 fingers (claw): jump/crouch while aiming, best for competitive.\nPut the fire button where your finger naturally lands and not too big (45–60%).",
                "✋ HUD:\n• 2 dedos: más fácil de aprender, bueno para empezar.\n• 3 dedos: índice izquierdo en disparo, apuntas y disparas a la vez.\n• 4 dedos (garra): saltar/agacharte mientras apuntas, mejor para competitivo.\nPon el botón de disparo donde cae natural tu dedo y no muy grande (45–60%).")
            has(q, "trav", "lag", "lagging", "fps", "esquent", "quente", "lento", "engasg", "calienta", "caliente", "hot", "slow", "stutter") -> t(
                "🐢 Celular travando:\n• Gráficos em Suave e FPS em Alto (estabilidade > beleza).\n• Use LIBERAR RAM na aba OTIMIZAR do painel antes da partida.\n• Tire a capa e evite jogar carregando.\n• Ative o modo Jogo/Game Turbo do celular e o Não Perturbe.\n• Deixe pelo menos 2 GB livres no armazenamento.",
                "🐢 Phone lagging:\n• Graphics on Smooth and FPS on High (stability > looks).\n• Use FREE UP RAM in the panel's BOOST tab before the match.\n• Remove the case and avoid playing while charging.\n• Turn on Game mode/Game Turbo and Do Not Disturb.\n• Keep at least 2 GB of free storage.",
                "🐢 Celular con lag:\n• Gráficos en Suave y FPS en Alto (estabilidad > apariencia).\n• Usa LIBERAR RAM en la pestaña OPTIMIZAR del panel antes de la partida.\n• Quita la funda y evita jugar cargando.\n• Activa el modo Juego/Game Turbo y No Molestar.\n• Deja al menos 2 GB libres de almacenamiento.")
            has(q, "dpi", "largura minima", "smallest width", "ancho minimo") -> t(
                "📐 DPI (largura mínima) aumenta a velocidade dos toques na tela. É opcional e fica em Opções do desenvolvedor. Mude aos poucos (+20 por vez); se a tela ficar estranha, volte ao valor original. A sensi do jogo importa mais que o DPI.",
                "📐 DPI (smallest width) makes touches feel faster. It's optional and lives in Developer options. Change it slowly (+20 at a time); if the screen looks odd, go back to the original. In-game sens matters more than DPI.",
                "📐 El DPI (ancho mínimo) hace que los toques se sientan más rápidos. Es opcional y está en Opciones de desarrollador. Cámbialo poco a poco (+20 cada vez); si la pantalla se ve rara, vuelve al valor original. La sensi del juego importa más que el DPI.")
            has(q, "ping", "internet", "wifi", "conexao", "conexion", "connection", "4g", "5g") -> t(
                "📶 Ping alto:\n• Prefira Wi-Fi 5 GHz perto do roteador.\n• Feche downloads e vídeos em segundo plano.\n• No 4G/5G, evite lugares com sinal fraco.\n• Escolha o servidor mais próximo de você.",
                "📶 High ping:\n• Prefer 5 GHz Wi-Fi close to the router.\n• Close downloads and videos in the background.\n• On 4G/5G, avoid weak-signal spots.\n• Pick the server closest to you.",
                "📶 Ping alto:\n• Prefiere Wi-Fi 5 GHz cerca del router.\n• Cierra descargas y videos en segundo plano.\n• En 4G/5G, evita lugares con señal débil.\n• Elige el servidor más cercano.")
            has(q, "trein", "melhorar", "evoluir", "train", "improve", "practice", "entren", "mejorar", "practicar") -> t(
                "🏋 Rotina de treino (15 min por dia):\n• 5 min na Sala de Treino acertando cabeça nos bonecos parados.\n• 5 min nos bonecos em movimento, puxando a mira num movimento só.\n• 5 min de X1 com amigo ou Contra Squad.\nNão mude a sensi todo dia: dê pelo menos 3 dias para se acostumar.",
                "🏋 Training routine (15 min a day):\n• 5 min in the Training Ground hitting heads on still dummies.\n• 5 min on moving dummies, dragging in one motion.\n• 5 min of 1v1 with a friend or Clash Squad.\nDon't change your sens every day: give it at least 3 days.",
                "🏋 Rutina de entrenamiento (15 min al día):\n• 5 min en el Campo de Entrenamiento acertando a la cabeza de muñecos quietos.\n• 5 min en muñecos en movimiento, subiendo en un solo movimiento.\n• 5 min de 1v1 con un amigo o Duelo de Escuadras.\nNo cambies la sensi todos los días: dale al menos 3 días.")
            has(q, "arma", "armas", "weapon", "gun", "arma ") -> t(
                "🔫 Para capa, armas de tiro único ou de dano alto na cabeça costumam ir melhor (como Desert Eagle, Woodpecker e as escopetas de perto). O meta muda a cada atualização, então teste no treino quais você acerta mais.",
                "🔫 For headshots, single-shot or high head-damage weapons usually work best (like Desert Eagle, Woodpecker and close-range shotguns). The meta changes every update, so test in training which ones you hit most.",
                "🔫 Para tiros a la cabeza suelen ir mejor las armas de un disparo o de mucho daño en la cabeza (como Desert Eagle, Woodpecker y escopetas de cerca). El meta cambia en cada actualización, así que prueba en el entrenamiento cuáles aciertas más.")
            has(q, "botao", "boton", "button", "tiro", "fire") -> t(
                "🔘 Botão de tiro: entre 45% e 60% costuma ser o ideal. Grande demais atrapalha a mira; pequeno demais você erra o toque. Na sensi que eu crio já vai a sugestão para o seu celular.",
                "🔘 Fire button: 45% to 60% is usually ideal. Too big gets in the way of aiming; too small and you miss the tap. The sens I create already includes a suggestion for your phone.",
                "🔘 Botón de disparo: entre 45% y 60% suele ser lo ideal. Muy grande estorba al apuntar; muy pequeño fallas el toque. La sensi que creo ya incluye la sugerencia para tu celular.")
            has(q, "painel", "panel", "flutuante", "flotante", "floating", "bolha", "burbuja", "bubble", "mira flut") -> t(
                "◎ Na aba MIRA, toque em ATIVAR PAINEL FLUTUANTE ou JOGAR FREE FIRE. Durante a partida, toque na bolha para mudar a mira, os modos, os filtros e ver sua sensi salva.",
                "◎ In the AIM tab, tap START FLOATING PANEL or PLAY FREE FIRE. During the match, tap the bubble to change the crosshair, modes, filters and see your saved sens.",
                "◎ En la pestaña MIRA, toca ACTIVAR PANEL FLOTANTE o JUGAR FREE FIRE. Durante la partida, toca la burbuja para cambiar la mira, modos, filtros y ver tu sensi guardada.")
            has(q, "olhadinha", "free look", "vista libre") -> t(
                "👀 Olhadinha (free look) serve para olhar em volta sem mudar a direção da corrida. Não afeta a mira, então pode deixar média-alta para checar inimigos rápido.",
                "👀 Free Look lets you look around without changing where you run. It doesn't affect aiming, so a mid-high value helps you check enemies quickly.",
                "👀 La Vista Libre sirve para mirar alrededor sin cambiar la dirección al correr. No afecta la puntería, así que un valor medio-alto ayuda a revisar enemigos rápido.")
            has(q, "oi", "ola", "eae", "salve", "hello", "hi ", "hey", "hola", "buenas", "bom dia", "boa tarde", "boa noite") || q == "hi" -> t(
                "Salve! 😎 Quer que eu crie sua sensibilidade ou tem alguma dúvida de jogabilidade?",
                "Hey! 😎 Want me to create your sensitivity or do you have a gameplay question?",
                "¡Hola! 😎 ¿Quieres que cree tu sensibilidad o tienes alguna duda de juego?")
            has(q, "obrigad", "valeu", "vlw", "thanks", "thank", "gracias", "tmj") -> t(
                "Tamo junto! 🤝 Bora pegar Mestre. Se precisar ajustar a sensi, é só chamar.",
                "Anytime! 🤝 Go get that rank. If you need to tune your sens, just ask.",
                "¡De nada! 🤝 A subir de rango. Si necesitas ajustar la sensi, aquí estoy.")
            else -> null
        }
        if (text != null) return listOf(Reply.Text(text))
        return listOf(Reply.Choices(t(
            "Hmm, não entendi bem. 🤔 Posso criar sua sensi (é só dizer o modelo do celular), ajustar se a mira passa ou não sobe, e dar dicas de capa, HUD, travamento, ping e treino.",
            "Hmm, I didn't quite get that. 🤔 I can create your sens (just tell me your phone model), tune it if your aim overshoots or stays low, and give tips on headshots, HUD, lag, ping and training.",
            "Hmm, no entendí bien. 🤔 Puedo crear tu sensi (dime el modelo de tu celular), ajustarla si la mira se pasa o no sube, y darte consejos de tiros a la cabeza, HUD, lag, ping y entrenamiento."),
            quickChips))
    }

    // ------------------------------------------------------------------ util
    private fun c(v: Int, min: Int = 1) = v.coerceIn(min, 200)

    private fun has(q: String, vararg keys: String): Boolean {
        val padded = " $q "
        return keys.any { k ->
            if (k.length <= 3 && !k.contains(" ")) padded.contains(" $k ") else padded.contains(k)
        }
    }

    private val phoneKeys: List<Pair<String, Phone>> by lazy {
        val out = ArrayList<Pair<String, Phone>>()
        for (p in PhoneDb.all(ctx)) {
            val n = PhoneDb.normalize(p.name).replace(" ", "")
            val full = PhoneDb.normalize("${p.brand} ${p.name}").replace(" ", "")
            if (n.length >= 4 || (n.length >= 3 && n.any { it.isDigit() })) out.add(n to p)
            out.add(full to p)
            val bases = mutableListOf(n)
            if (n.endsWith("5g") && n.length > 5) bases.add(n.dropLast(2))
            for (b in bases) {
                if (b != n && b.length >= 4) out.add(b to p)
                if (b.startsWith("galaxy")) b.removePrefix("galaxy").let { if (it.length >= 3) out.add(it to p) }
            }
        }
        out.sortedByDescending { it.first.length }
    }

    /** Procura o modelo de celular mais específico citado na frase. */
    private fun findPhone(q: String): Phone? {
        val compact = q.replace(" ", "")
        return phoneKeys.firstOrNull { (key, _) ->
            val i = compact.indexOf(key)
            // evita "a10" casar com "a105": o próximo caractere não pode ser dígito
            i >= 0 && (i + key.length >= compact.length || !compact[i + key.length].isDigit() || !key.last().isDigit())
        }?.second
    }
}

/** Liga a tela de chat ao cérebro. */
class AiChatController(
    private val act: Activity,
    root: View,
    private val prefs: Prefs,
    private val onSaved: () -> Unit
) {
    private val brain = NexusBrain(act, prefs)
    private val list: LinearLayout = root.findViewById(R.id.chatList)
    private val scroll: ScrollView = root.findViewById(R.id.chatScroll)
    private val input: EditText = root.findViewById(R.id.chatInput)
    private val quick: LinearLayout = root.findViewById(R.id.quickRow)
    private val handler = Handler(Looper.getMainLooper())
    private var typing: View? = null
    private var started = false

    init {
        root.findViewById<TextView>(R.id.chatSend).setOnClickListener { send(input.text.toString()) }
        input.setOnEditorActionListener { _, id, ev ->
            if (id == EditorInfo.IME_ACTION_SEND || ev?.keyCode == KeyEvent.KEYCODE_ENTER) {
                send(input.text.toString()); true
            } else false
        }
        brain.quickChips.forEach { chip ->
            quick.addView(Ui.chip(act, chip, false).apply { setOnClickListener { send(chip) } })
        }
    }

    fun onShown() {
        if (started) return
        started = true
        botReplies(brain.greet())
    }

    private fun send(text: String) {
        val msg = text.trim()
        if (msg.isEmpty() || typing != null) return
        input.setText("")
        addBubble(msg, user = true)
        botReplies(brain.handle(msg))
    }

    private fun botReplies(replies: List<NexusBrain.Reply>) {
        if (replies.isEmpty()) return
        typing = Ui.text(act, act.getString(R.string.ai_typing), 10f, Ui.MUTED).also {
            list.addView(it, Ui.lp(top = Ui.dp(act, 6)))
        }
        scrollDown()
        handler.postDelayed({
            typing?.let { list.removeView(it) }
            typing = null
            replies.forEach { render(it) }
            scrollDown()
        }, 550)
    }

    private fun render(r: NexusBrain.Reply) {
        when (r) {
            is NexusBrain.Reply.Text -> addBubble(r.text, user = false)
            is NexusBrain.Reply.Choices -> {
                if (r.text.isNotEmpty()) addBubble(r.text, user = false)
                addChoices(r.options)
            }
            is NexusBrain.Reply.Sens -> {
                addBubble(r.text, user = false)
                addSensCard(r.result)
            }
        }
    }

    private fun addBubble(text: String, user: Boolean) {
        val tv = Ui.text(act, text, 13f, Ui.TEXT).apply {
            setBackgroundResource(if (user) R.drawable.bg_bubble_user else R.drawable.bg_bubble_bot)
            setPadding(Ui.dp(act, 12), Ui.dp(act, 9), Ui.dp(act, 12), Ui.dp(act, 9))
            setLineSpacing(0f, 1.25f)
            setTextIsSelectable(true)
        }
        val wrap = LinearLayout(act).apply {
            gravity = if (user) Gravity.END else Gravity.START
            if (!user) {
                addView(Ui.text(act, "✦", 14f, Ui.MAGENTA, true).apply {
                    setPadding(0, Ui.dp(act, 6), Ui.dp(act, 6), 0)
                })
            }
            val maxW = (act.resources.displayMetrics.widthPixels * 0.74f).toInt()
            tv.maxWidth = maxW
            addView(tv)
        }
        list.addView(wrap, LinearLayout.LayoutParams(-1, -2).apply { topMargin = Ui.dp(act, 8) })
    }

    private fun addChoices(options: List<String>) {
        if (options.isEmpty()) return
        val box = Ui.vBox(act).apply { setPadding(Ui.dp(act, 20), 0, 0, 0) }
        options.forEach { o ->
            val chip = Ui.chip(act, o, true, 12f).apply {
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                setOnClickListener { send(o) }
            }
            box.addView(chip, LinearLayout.LayoutParams(-2, -2).apply { topMargin = Ui.dp(act, 6) })
        }
        list.addView(box)
    }

    private fun addSensCard(r: SensResult) {
        val card = Ui.vBox(act).apply {
            setBackgroundResource(R.drawable.bg_panel)
            setPadding(Ui.dp(act, 14), Ui.dp(act, 12), Ui.dp(act, 14), Ui.dp(act, 12))
        }
        card.addView(Ui.text(act, r.title, 14f, Ui.CYAN, true))
        card.addView(Ui.text(act, r.specs, 10f, Ui.MUTED), Ui.lp(top = Ui.dp(act, 2)))
        card.addView(Ui.sensBar(act, act.getString(R.string.s_general), r.geral), Ui.lp(top = Ui.dp(act, 6)))
        card.addView(Ui.sensBar(act, act.getString(R.string.s_reddot), r.redDot))
        card.addView(Ui.sensBar(act, act.getString(R.string.s_2x), r.x2))
        card.addView(Ui.sensBar(act, act.getString(R.string.s_4x), r.x4))
        card.addView(Ui.sensBar(act, act.getString(R.string.s_awm), r.awm))
        card.addView(Ui.sensBar(act, act.getString(R.string.s_freelook), r.olhadinha))
        val extra = (if (r.dpi != null) act.getString(R.string.dpi_fmt, r.dpi) + "  ·  " else "") +
            act.getString(R.string.fire_fmt, r.fireButton) + "\n" + act.getString(R.string.gfx_fmt, r.graphics, r.fps)
        card.addView(Ui.text(act, extra, 11f, Ui.TEXT).apply { setLineSpacing(0f, 1.25f) }, Ui.lp(top = Ui.dp(act, 6)))

        val row = Ui.hRow(act)
        val save = Ui.button(act, act.getString(R.string.save_panel))
        val copy = Ui.button(act, act.getString(R.string.copy))
        row.addView(save, LinearLayout.LayoutParams(0, -2, 1.4f))
        row.addView(View(act), LinearLayout.LayoutParams(Ui.dp(act, 8), 1))
        row.addView(copy, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(row, Ui.lp(top = Ui.dp(act, 10)))
        save.setOnClickListener {
            prefs.sensJson = r.toJson()
            onSaved()
            save.text = act.getString(R.string.ai_saved)
            Toast.makeText(act, R.string.saved_toast, Toast.LENGTH_SHORT).show()
        }
        copy.setOnClickListener {
            val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("sens", r.asText(act)))
            Toast.makeText(act, R.string.copied_toast, Toast.LENGTH_SHORT).show()
        }
        list.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = Ui.dp(act, 8); marginStart = Ui.dp(act, 20)
        })
    }

    private fun scrollDown() {
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }
}
