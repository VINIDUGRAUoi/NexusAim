package com.nexusaim.ff

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

class CrosshairView @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : View(ctx, attrs) {

    var styleIndex = 3
    var color = Color.RED
    var sizeDp = 36
    var thickDp = 2
    var alphaPct = 100
    var glow = true

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val oval = RectF()

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    fun load(prefs: Prefs) {
        styleIndex = prefs.style; color = prefs.color; sizeDp = prefs.size
        thickDp = prefs.thick; alphaPct = prefs.alpha; glow = prefs.glow
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val d = resources.displayMetrics.density
        val cx = width / 2f
        val cy = height / 2f
        val r = sizeDp * d / 2f
        val t = thickDp * d
        val gap = r * 0.32f

        p.color = color
        p.alpha = (alphaPct * 255 / 100).coerceIn(0, 255)
        p.strokeWidth = t
        p.strokeCap = Paint.Cap.ROUND
        if (glow) p.setShadowLayer(t * 2.5f + 2f, 0f, 0f, color) else p.clearShadowLayer()

        fun line(x1: Float, y1: Float, x2: Float, y2: Float) {
            p.style = Paint.Style.STROKE; c.drawLine(x1, y1, x2, y2, p)
        }
        fun dot(rad: Float) {
            p.style = Paint.Style.FILL; c.drawCircle(cx, cy, rad, p)
        }
        fun ring(rad: Float) {
            p.style = Paint.Style.STROKE; c.drawCircle(cx, cy, rad, p)
        }
        fun cross(gapV: Float, len: Float) {
            line(cx - len, cy, cx - gapV, cy); line(cx + gapV, cy, cx + len, cy)
            line(cx, cy - len, cx, cy - gapV); line(cx, cy + gapV, cx, cy + len)
        }

        when (styleIndex) {
            0 -> cross(gap, r)
            1 -> dot(maxOf(t * 1.6f, r * 0.22f))
            2 -> { ring(r * 0.75f); dot(t * 0.9f) }
            3 -> { cross(gap, r); dot(t * 0.9f) }
            4 -> {
                line(cx - r, cy, cx - gap, cy); line(cx + gap, cy, cx + r, cy)
                line(cx, cy + gap, cx, cy + r); dot(t * 0.9f)
            }
            5 -> {
                ring(r * 0.8f)
                cross(r * 0.25f, r * 1.15f)
                dot(t * 0.8f)
            }
            6 -> {
                val k = 0.7071f
                line(cx - r * k, cy - r * k, cx - gap * k, cy - gap * k)
                line(cx + gap * k, cy + gap * k, cx + r * k, cy + r * k)
                line(cx + r * k, cy - r * k, cx + gap * k, cy - gap * k)
                line(cx - gap * k, cy + gap * k, cx - r * k, cy + r * k)
            }
            else -> {
                p.style = Paint.Style.STROKE
                val rr = r * 0.8f
                oval.set(cx - rr, cy - rr, cx + rr, cy + rr)
                for (i in 0 until 4) c.drawArc(oval, i * 90f + 15f, 60f, false, p)
                dot(t * 0.9f)
            }
        }
    }
}
