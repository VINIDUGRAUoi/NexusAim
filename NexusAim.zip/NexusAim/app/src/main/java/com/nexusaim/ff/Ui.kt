package com.nexusaim.ff

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import kotlin.math.roundToInt

object Ui {
    val CYAN = Color.parseColor("#00F0FF")
    val MAGENTA = Color.parseColor("#FF2BD6")
    val TEXT = Color.parseColor("#E8F7FF")
    val MUTED = Color.parseColor("#7F93B3")
    val LIME = Color.parseColor("#39FF14")
    val DANGER = Color.parseColor("#FF3B5C")

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).roundToInt()

    fun text(c: Context, s: String, sp: Float = 12f, color: Int = TEXT, bold: Boolean = false) =
        TextView(c).apply {
            text = s; textSize = sp; setTextColor(color)
            typeface = Typeface.create(Typeface.MONOSPACE, if (bold) Typeface.BOLD else Typeface.NORMAL)
        }

    fun chip(c: Context, s: String, on: Boolean, sp: Float = 11f) = text(c, s, sp, if (on) CYAN else TEXT, on).apply {
        setBackgroundResource(if (on) R.drawable.bg_chip_on else R.drawable.bg_chip)
        gravity = Gravity.CENTER
        setPadding(dp(c, 12), dp(c, 8), dp(c, 12), dp(c, 8))
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { marginEnd = dp(c, 8) }
    }

    fun button(c: Context, s: String, danger: Boolean = false) = text(c, s, 12f, Color.WHITE, true).apply {
        setBackgroundResource(if (danger) R.drawable.bg_button_off else R.drawable.bg_button)
        gravity = Gravity.CENTER
        setPadding(dp(c, 12), dp(c, 10), dp(c, 12), dp(c, 10))
    }

    fun colorDot(c: Context, color: Int, selected: Boolean, sizeDp: Int = 32) = TextView(c).apply {
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
            setStroke(dp(c, if (selected) 3 else 1), if (selected) Color.WHITE else Color.parseColor("#33FFFFFF"))
        }
        layoutParams = LinearLayout.LayoutParams(dp(c, sizeDp), dp(c, sizeDp)).apply { marginEnd = dp(c, 10) }
    }

    fun hRow(c: Context) = LinearLayout(c).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    fun vBox(c: Context) = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }

    /** Linha "Rótulo ▓▓▓▓░░ 180" para a sensibilidade. */
    fun sensBar(c: Context, label: String, value: Int, max: Int = 200): LinearLayout {
        val box = vBox(c).apply { setPadding(0, dp(c, 5), 0, dp(c, 5)) }
        val top = hRow(c)
        top.addView(text(c, label, 12f, TEXT), LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(text(c, value.toString(), 14f, CYAN, true))
        box.addView(top)
        val bar = ProgressBar(c, null, android.R.attr.progressBarStyleHorizontal).apply {
            this.max = max; progress = value
            progressDrawable = c.getDrawable(R.drawable.bg_bar)
        }
        box.addView(bar, LinearLayout.LayoutParams(-1, dp(c, 6)).apply { topMargin = dp(c, 4) })
        return box
    }

    fun lp(w: Int = -1, h: Int = -2, top: Int = 0) =
        LinearLayout.LayoutParams(w, h).apply { topMargin = top }
}
