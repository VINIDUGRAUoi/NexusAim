package com.nexusaim.ff

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View

/** Fundo futurista: grade neon + linha de varredura animada. */
class GridBackgroundView @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : View(ctx, attrs) {

    private val grid = Paint().apply { color = 0x1400F0FF; strokeWidth = 1f }
    private val scan = Paint()
    private var scanY = 0f
    private val d = resources.displayMetrics.density

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val step = 28 * d
        var x = 0f
        while (x < width) { c.drawLine(x, 0f, x, height.toFloat(), grid); x += step }
        var y = 0f
        while (y < height) { c.drawLine(0f, y, width.toFloat(), y, grid); y += step }

        val h = 60 * d
        scan.shader = LinearGradient(
            0f, scanY - h, 0f, scanY, 0x0000F0FF, 0x2A00F0FF, Shader.TileMode.CLAMP
        )
        c.drawRect(0f, scanY - h, width.toFloat(), scanY, scan)

        scanY += 2.2f * d
        if (scanY > height + h) scanY = 0f
        if (isShown) postInvalidateDelayed(24)
    }
}
