package com.nexusaim.ff

import org.json.JSONObject
import kotlin.math.roundToInt

data class SensResult(
    val title: String,
    val specs: String,
    val geral: Int, val redDot: Int, val x2: Int, val x4: Int, val awm: Int, val olhadinha: Int,
    val dpi: Int?, val fireButton: Int, val graphics: String, val fps: String
) {
    fun toJson(): String = JSONObject().apply {
        put("title", title); put("specs", specs)
        put("geral", geral); put("redDot", redDot); put("x2", x2); put("x4", x4)
        put("awm", awm); put("olhadinha", olhadinha); put("dpi", dpi ?: -1)
        put("fire", fireButton); put("gfx", graphics); put("fps", fps)
    }.toString()

    fun asText(): String = buildString {
        appendLine("🎯 Sensibilidade FF — $title")
        appendLine("Geral: $geral")
        appendLine("Ponto Vermelho: $redDot")
        appendLine("Mira 2x: $x2")
        appendLine("Mira 4x: $x4")
        appendLine("Mira AWM: $awm")
        appendLine("Olhadinha: $olhadinha")
        if (dpi != null) appendLine("DPI sugerido: $dpi")
        appendLine("Botão de tiro: $fireButton%")
        append("Gráficos: $graphics · FPS: $fps")
    }

    companion object {
        fun fromJson(s: String): SensResult? = try {
            val o = JSONObject(s)
            SensResult(
                o.getString("title"), o.getString("specs"),
                o.getInt("geral"), o.getInt("redDot"), o.getInt("x2"), o.getInt("x4"),
                o.getInt("awm"), o.getInt("olhadinha"),
                o.getInt("dpi").takeIf { it > 0 }, o.getInt("fire"),
                o.getString("gfx"), o.getString("fps")
            )
        } catch (e: Exception) { null }
    }
}

object SensitivityCalculator {

    fun calc(p: Phone): SensResult = calc(
        p.fullName, p.tier, p.hz, p.inch, p.year, p.isApple,
        "${p.year} · ${fmtInch(p.inch)}\" · ${p.hz}Hz · ${Catalog.tierNames[p.tier]}"
    )

    fun fmtInch(i: Double) = String.format(java.util.Locale.US, "%.1f", i)

    fun calc(
        title: String, tier: Int, hz: Int, inch: Double, year: Int, apple: Boolean, specs: String
    ): SensResult {
        val seed = title.hashCode()
        fun j(k: Int): Int = Math.floorMod(seed xor (k * 0x45D9F3B) xor (k shl 7), 7) - 3

        val base = when (tier) { 1 -> 193; 2 -> 185; 3 -> 177; else -> 169 }
        val inchAdj = ((inch - 6.4) * 6).roundToInt()
        val hzAdj = when {
            hz >= 165 -> -7; hz >= 144 -> -6; hz >= 120 -> -4; hz >= 90 -> 0; else -> 4
        }
        val ageAdj = if (year <= 2018) 3 else 0
        val appleAdj = if (apple) -6 else 0
        val g = base + inchAdj + hzAdj + ageAdj + appleAdj

        fun c(v: Int, min: Int = 1) = v.coerceIn(min, 200)

        val geral = c(g + j(1))
        val redDot = c(g - 5 + j(2))
        val x2 = c(g - 11 + j(3))
        val x4 = c(g - 19 + j(4))
        val awm = c((g * 0.48).roundToInt() + j(5), 40)
        val olhadinha = c(g - 8 + j(6), 50)

        val dpi = if (apple) null else {
            val d = 400 + when (tier) { 1 -> 120; 2 -> 90; 3 -> 60; else -> 40 } + ((inch - 6.0) * 20).roundToInt()
            (d / 10) * 10
        }
        val fire = (55 - (inch - 6.0) * 5).roundToInt().coerceIn(42, 62)
        val gfx = when (tier) { 1 -> "Suave"; 2 -> "Padrão"; 3 -> "Alto"; else -> "Ultra" }
        val fps = if (tier >= 3 || hz >= 90) "Alto / Máximo" else "Normal"

        return SensResult(title, specs, geral, redDot, x2, x4, awm, olhadinha, dpi, fire, gfx, fps)
    }
}
