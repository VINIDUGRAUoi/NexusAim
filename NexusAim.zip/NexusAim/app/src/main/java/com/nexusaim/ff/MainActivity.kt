package com.nexusaim.ff

import android.Manifest
import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.materialswitch.MaterialSwitch

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var aimTab: View
    private lateinit var sensTab: View
    private lateinit var tabAim: TextView
    private lateinit var tabSens: TextView
    private lateinit var preview: CrosshairView
    private lateinit var btnToggle: TextView
    private lateinit var txtOverlay: TextView
    private lateinit var btnGrant: TextView
    private lateinit var adapter: PhoneAdapter
    private var brandFilter: String? = null
    private var permissionAsked = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)

        aimTab = findViewById(R.id.aimTab)
        sensTab = findViewById(R.id.sensTab)
        tabAim = findViewById(R.id.tabAim)
        tabSens = findViewById(R.id.tabSens)
        tabAim.setOnClickListener { selectTab(0) }
        tabSens.setOnClickListener { selectTab(1) }
        selectTab(0)

        setupAimTab()
        setupSensTab()

        if (savedInstanceState == null && !Settings.canDrawOverlays(this)) {
            askOverlayPermission()
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        refreshSaved()
    }

    // ---------------------------------------------------------------- TABS
    private fun selectTab(i: Int) {
        aimTab.visibility = if (i == 0) View.VISIBLE else View.GONE
        sensTab.visibility = if (i == 1) View.VISIBLE else View.GONE
        tabAim.setBackgroundResource(if (i == 0) R.drawable.bg_button else 0)
        tabSens.setBackgroundResource(if (i == 1) R.drawable.bg_button else 0)
        if (i == 1) currentFocus?.clearFocus()
    }

    // ---------------------------------------------------------------- PERMISSÕES
    private fun askOverlayPermission() {
        if (permissionAsked && isFinishing) return
        permissionAsked = true
        neonDialog(
            "PERMISSÃO NECESSÁRIA",
            "Para a mira e o painel flutuante aparecerem por cima do Free Fire, o Nexus Aim precisa da permissão \"Sobrepor a outros apps\" (Exibir sobre outros apps).\n\nNa próxima tela, ative a chave do Nexus Aim e volte para o app.",
            "PERMITIR"
        ) { openOverlaySettings() }
    }

    private fun openOverlaySettings() {
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
        }
    }

    private fun ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
    }

    private fun refreshStatus() {
        val ok = Settings.canDrawOverlays(this)
        txtOverlay.text = if (ok) "Sobrepor a outros apps: ✔ ATIVA" else "Sobrepor a outros apps: ✖ NEGADA"
        txtOverlay.setTextColor(if (ok) Ui.LIME else Ui.DANGER)
        btnGrant.visibility = if (ok) View.GONE else View.VISIBLE
        val running = OverlayService.running
        btnToggle.text = if (running) "■ DESATIVAR PAINEL FLUTUANTE" else "▶ ATIVAR PAINEL FLUTUANTE"
        btnToggle.setBackgroundResource(if (running) R.drawable.bg_button_off else R.drawable.bg_button)
    }

    // ---------------------------------------------------------------- ABA MIRA
    private fun setupAimTab() {
        preview = findViewById(R.id.preview)
        btnToggle = findViewById(R.id.btnToggle)
        txtOverlay = findViewById(R.id.txtOverlayStatus)
        btnGrant = findViewById(R.id.btnGrant)
        btnGrant.setOnClickListener { openOverlaySettings() }

        btnToggle.setOnClickListener {
            if (OverlayService.running) {
                stopService(Intent(this, OverlayService::class.java))
                OverlayService.running = false
                btnToggle.postDelayed({ refreshStatus() }, 300)
            } else {
                if (!Settings.canDrawOverlays(this)) { askOverlayPermission(); return@setOnClickListener }
                ensureNotificationPermission()
                ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
                Toast.makeText(this, "Painel ativado! Abra o Free Fire.", Toast.LENGTH_SHORT).show()
                btnToggle.postDelayed({ refreshStatus() }, 400)
            }
        }

        val seekSize = findViewById<SeekBar>(R.id.seekSize)
        val seekThick = findViewById<SeekBar>(R.id.seekThick)
        val seekAlpha = findViewById<SeekBar>(R.id.seekAlpha)
        val lblSize = findViewById<TextView>(R.id.lblSize)
        val lblThick = findViewById<TextView>(R.id.lblThick)
        val lblAlpha = findViewById<TextView>(R.id.lblAlpha)
        val swGlow = findViewById<MaterialSwitch>(R.id.swGlow)

        seekSize.progress = prefs.size - 10
        seekThick.progress = prefs.thick - 1
        seekAlpha.progress = prefs.alpha - 20
        swGlow.isChecked = prefs.glow

        fun labels() {
            lblSize.text = "TAMANHO · ${prefs.size}"
            lblThick.text = "ESPESSURA · ${prefs.thick}"
            lblAlpha.text = "OPACIDADE · ${prefs.alpha}%"
        }
        labels()

        val listener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, v: Int, fromUser: Boolean) {
                if (!fromUser) return
                when (s.id) {
                    R.id.seekSize -> prefs.size = v + 10
                    R.id.seekThick -> prefs.thick = v + 1
                    R.id.seekAlpha -> prefs.alpha = v + 20
                }
                labels(); updatePreview()
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        }
        seekSize.setOnSeekBarChangeListener(listener)
        seekThick.setOnSeekBarChangeListener(listener)
        seekAlpha.setOnSeekBarChangeListener(listener)
        swGlow.setOnCheckedChangeListener { _, b -> prefs.glow = b; updatePreview() }

        buildStyleRow()
        buildColorRow()
        updatePreview()
    }

    private fun buildStyleRow() {
        val row = findViewById<LinearLayout>(R.id.styleRow)
        row.removeAllViews()
        Catalog.styleNames.forEachIndexed { i, name ->
            row.addView(Ui.chip(this, name, i == prefs.style).apply {
                setOnClickListener { prefs.style = i; buildStyleRow(); updatePreview() }
            })
        }
    }

    private fun buildColorRow() {
        val row = findViewById<LinearLayout>(R.id.colorRow)
        row.removeAllViews()
        Catalog.colors.forEach { col ->
            row.addView(Ui.colorDot(this, col, col == prefs.color).apply {
                setOnClickListener { prefs.color = col; buildColorRow(); updatePreview() }
            })
        }
    }

    private fun updatePreview() {
        preview.load(prefs)
        findViewById<TextView>(R.id.txtStyleName).text =
            Catalog.styleNames.getOrElse(prefs.style) { "" }.uppercase()
    }

    // ---------------------------------------------------------------- ABA SENSIBILIDADE
    private fun setupSensTab() {
        val recycler = findViewById<RecyclerView>(R.id.recycler)
        val search = findViewById<EditText>(R.id.search)
        val count = findViewById<TextView>(R.id.txtCount)
        adapter = PhoneAdapter { showResult(SensitivityCalculator.calc(it)) }
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        fun update() {
            val list = PhoneDb.search(this, search.text.toString(), brandFilter)
            adapter.submit(list)
            val total = PhoneDb.all(this).size
            count.text = if (list.isEmpty()) "Nenhum celular encontrado · use o MODO MANUAL"
            else "${list.size} de $total celulares (2017–2026)"
        }

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = update()
        })

        val brands = listOf<String?>(null) + PhoneDb.all(this).map { it.brand }.distinct()
        val brandRow = findViewById<LinearLayout>(R.id.brandRow)
        fun buildBrands() {
            brandRow.removeAllViews()
            brands.forEach { b ->
                brandRow.addView(Ui.chip(this, b ?: "Todas", b == brandFilter).apply {
                    setOnClickListener { brandFilter = b; buildBrands(); update() }
                })
            }
        }
        buildBrands()
        findViewById<TextView>(R.id.btnManual).setOnClickListener { showManual() }
        update()
    }

    private fun refreshSaved() {
        val t = findViewById<TextView>(R.id.txtSaved)
        val s = SensResult.fromJson(prefs.sensJson)
        if (s == null) { t.visibility = View.GONE; return }
        t.visibility = View.VISIBLE
        t.text = "✔ No painel flutuante: ${s.title}  (Geral ${s.geral} · PV ${s.redDot} · 2x ${s.x2} · 4x ${s.x4})"
        t.setOnClickListener { showResult(s) }
    }

    private fun showResult(r: SensResult) {
        val c = this
        val root = Ui.vBox(c).apply {
            setBackgroundResource(R.drawable.bg_panel)
            setPadding(Ui.dp(c, 20), Ui.dp(c, 20), Ui.dp(c, 20), Ui.dp(c, 16))
        }
        root.addView(Ui.text(c, "// SENSIBILIDADE GERADA", 11f, Ui.MAGENTA, true))
        root.addView(Ui.text(c, r.title, 18f, Ui.CYAN, true), Ui.lp(top = Ui.dp(c, 6)))
        root.addView(Ui.text(c, r.specs, 11f, Ui.MUTED), Ui.lp(top = Ui.dp(c, 2)))

        val bars = Ui.vBox(c)
        bars.addView(Ui.sensBar(c, "Geral", r.geral))
        bars.addView(Ui.sensBar(c, "Ponto Vermelho", r.redDot))
        bars.addView(Ui.sensBar(c, "Mira 2x", r.x2))
        bars.addView(Ui.sensBar(c, "Mira 4x", r.x4))
        bars.addView(Ui.sensBar(c, "Mira AWM", r.awm))
        bars.addView(Ui.sensBar(c, "Olhadinha", r.olhadinha))
        root.addView(bars, Ui.lp(top = Ui.dp(c, 12)))

        val extra = buildString {
            if (r.dpi != null) append("DPI sugerido: ${r.dpi}\n")
            append("Botão de tiro: ${r.fireButton}%\n")
            append("Gráficos: ${r.graphics}  ·  FPS: ${r.fps}")
        }
        root.addView(Ui.text(c, extra, 12f, Ui.TEXT).apply {
            setBackgroundResource(R.drawable.bg_chip)
            setPadding(Ui.dp(c, 12), Ui.dp(c, 10), Ui.dp(c, 12), Ui.dp(c, 10))
            setLineSpacing(0f, 1.3f)
        }, Ui.lp(top = Ui.dp(c, 12)))
        if (r.dpi != null) {
            root.addView(Ui.text(c, "DPI é opcional: Opções do desenvolvedor › Largura mínima. Escala 0–200 (FF atual).", 10f, Ui.MUTED),
                Ui.lp(top = Ui.dp(c, 6)))
        }

        val row = Ui.hRow(c)
        val btnSave = Ui.button(c, "SALVAR NO PAINEL")
        val btnCopy = Ui.button(c, "COPIAR")
        row.addView(btnSave, LinearLayout.LayoutParams(0, -2, 1.4f))
        row.addView(View(c), LinearLayout.LayoutParams(Ui.dp(c, 10), 1))
        row.addView(btnCopy, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row, Ui.lp(top = Ui.dp(c, 14)))

        val scroll = ScrollView(c).apply { addView(root) }
        val dialog = AlertDialog.Builder(c).setView(scroll).create()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        btnSave.setOnClickListener {
            prefs.sensJson = r.toJson()
            refreshSaved()
            Toast.makeText(c, "Salvo! Veja na aba SENS do painel flutuante.", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }
        btnCopy.setOnClickListener {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("sens", r.asText()))
            Toast.makeText(c, "Sensibilidade copiada", Toast.LENGTH_SHORT).show()
        }
        dialog.show()
    }

    private fun showManual() {
        val c = this
        var inch = 6.5
        var hz = 90
        var tier = 2
        val root = Ui.vBox(c).apply {
            setBackgroundResource(R.drawable.bg_panel)
            setPadding(Ui.dp(c, 20), Ui.dp(c, 20), Ui.dp(c, 20), Ui.dp(c, 16))
        }
        root.addView(Ui.text(c, "// MODO MANUAL", 11f, Ui.MAGENTA, true))
        root.addView(Ui.text(c, "Não achou seu celular? Informe os dados dele:", 12f, Ui.TEXT), Ui.lp(top = Ui.dp(c, 6)))

        val name = EditText(c).apply {
            hint = "Nome do celular (opcional)"; setTextColor(Ui.TEXT); setHintTextColor(Ui.MUTED)
            textSize = 13f; setBackgroundResource(R.drawable.bg_input)
            setPadding(Ui.dp(c, 14), Ui.dp(c, 10), Ui.dp(c, 14), Ui.dp(c, 10))
        }
        root.addView(name, Ui.lp(top = Ui.dp(c, 12)))

        val lblInch = Ui.text(c, "", 12f, Ui.MUTED)
        root.addView(lblInch, Ui.lp(top = Ui.dp(c, 14)))
        val seek = SeekBar(c).apply { max = 30; progress = 15 }
        fun lbl() { lblInch.text = "TELA · ${SensitivityCalculator.fmtInch(inch)} polegadas" }
        lbl()
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, v: Int, f: Boolean) { inch = 5.0 + v / 10.0; lbl() }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        root.addView(seek, Ui.lp())

        root.addView(Ui.text(c, "TAXA DE ATUALIZAÇÃO", 12f, Ui.MUTED), Ui.lp(top = Ui.dp(c, 12)))
        val hzRow = Ui.hRow(c)
        val hzList = listOf(60, 90, 120, 144)
        fun buildHz() {
            hzRow.removeAllViews()
            hzList.forEach { h ->
                hzRow.addView(Ui.chip(c, "${h}Hz", h == hz).apply { setOnClickListener { hz = h; buildHz() } })
            }
        }
        buildHz()
        root.addView(hzRow, Ui.lp(top = Ui.dp(c, 6)))

        root.addView(Ui.text(c, "DESEMPENHO DO CELULAR", 12f, Ui.MUTED), Ui.lp(top = Ui.dp(c, 12)))
        val tierBox = Ui.vBox(c)
        fun buildTier() {
            tierBox.removeAllViews()
            val r1 = Ui.hRow(c); val r2 = Ui.hRow(c)
            for (t in 1..4) {
                val chip = Ui.chip(c, Catalog.tierNames[t], t == tier).apply { setOnClickListener { tier = t; buildTier() } }
                if (t <= 2) r1.addView(chip) else r2.addView(chip)
            }
            tierBox.addView(r1); tierBox.addView(r2, Ui.lp(top = Ui.dp(c, 6)))
        }
        buildTier()
        root.addView(tierBox, Ui.lp(top = Ui.dp(c, 6)))

        val gen = Ui.button(c, "⚡ GERAR SENSIBILIDADE")
        root.addView(gen, Ui.lp(top = Ui.dp(c, 16)))

        val dialog = AlertDialog.Builder(c).setView(ScrollView(c).apply { addView(root) }).create()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        gen.setOnClickListener {
            val title = name.text.toString().trim().ifEmpty { "Celular personalizado" }
            val specs = "${SensitivityCalculator.fmtInch(inch)}\" · ${hz}Hz · ${Catalog.tierNames[tier]}"
            dialog.dismiss()
            showResult(SensitivityCalculator.calc(title, tier, hz, inch, 2022, false, specs))
        }
        dialog.show()
    }

    private fun neonDialog(title: String, msg: String, action: String, onOk: () -> Unit) {
        val c = this
        val root = Ui.vBox(c).apply {
            setBackgroundResource(R.drawable.bg_panel)
            setPadding(Ui.dp(c, 22), Ui.dp(c, 22), Ui.dp(c, 22), Ui.dp(c, 18))
        }
        root.addView(Ui.text(c, "⚠ $title", 15f, Ui.CYAN, true))
        root.addView(Ui.text(c, msg, 13f, Ui.TEXT).apply { setLineSpacing(0f, 1.3f) }, Ui.lp(top = Ui.dp(c, 12)))
        val row = Ui.hRow(c)
        val later = Ui.button(c, "DEPOIS", danger = true)
        val ok = Ui.button(c, action)
        row.addView(later, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(View(c), LinearLayout.LayoutParams(Ui.dp(c, 10), 1))
        row.addView(ok, LinearLayout.LayoutParams(0, -2, 1.3f))
        root.addView(row, Ui.lp(top = Ui.dp(c, 18)))
        val d = AlertDialog.Builder(c).setView(root).create()
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        later.setOnClickListener { d.dismiss() }
        ok.setOnClickListener { d.dismiss(); onOk() }
        d.show()
    }
}

class PhoneAdapter(private val onClick: (Phone) -> Unit) : RecyclerView.Adapter<PhoneAdapter.VH>() {
    private var items: List<Phone> = emptyList()

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tier: TextView = v.findViewById(R.id.tier)
        val name: TextView = v.findViewById(R.id.name)
        val specs: TextView = v.findViewById(R.id.specs)
    }

    @SuppressLint("NotifyDataSetChanged")
    fun submit(list: List<Phone>) { items = list; notifyDataSetChanged() }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_phone, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, pos: Int) {
        val p = items[pos]
        h.name.text = p.fullName
        h.specs.text = "${p.year} · ${SensitivityCalculator.fmtInch(p.inch)}\" · ${p.hz}Hz · ${Catalog.tierNames[p.tier]}"
        h.tier.text = when (p.tier) { 1 -> "B"; 2 -> "I"; 3 -> "A"; else -> "T" }
        h.tier.setTextColor(when (p.tier) { 1 -> Ui.MUTED; 2 -> Ui.CYAN; 3 -> Ui.MAGENTA; else -> Ui.LIME })
        h.itemView.setOnClickListener { onClick(p) }
    }
}
