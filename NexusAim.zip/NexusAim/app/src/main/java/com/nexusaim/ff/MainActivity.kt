package com.nexusaim.ff

import android.Manifest
import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.materialswitch.MaterialSwitch

class MainActivity : AppCompatActivity() {

    companion object {
        const val INSTAGRAM = "https://www.instagram.com/x_mlk_vini"
        const val TIKTOK = "https://www.tiktok.com/@vgking7x"
        val LANGUAGES = listOf("" to "🌐", "pt" to "🇧🇷 Português", "en" to "🇺🇸 English", "es" to "🇪🇸 Español")
    }

    private lateinit var prefs: Prefs
    private lateinit var aimTab: View
    private lateinit var sensTab: View
    private lateinit var tabAim: TextView
    private lateinit var tabSens: TextView
    private lateinit var preview: CrosshairView
    private lateinit var btnToggle: TextView
    private lateinit var txtOverlay: TextView
    private lateinit var btnGrant: TextView
    private lateinit var adapter: PhoneAdapter
    private var brandFilter: String? = null

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)

        aimTab = findViewById(R.id.aimTab)
        sensTab = findViewById(R.id.sensTab)
        tabAim = findViewById(R.id.tabAim)
        tabSens = findViewById(R.id.tabSens)
        tabAim.setOnClickListener { selectTab(0) }
        tabSens.setOnClickListener { selectTab(1) }
        findViewById<TextView>(R.id.btnSettings).setOnClickListener { showSettings() }

        setupAimTab()
        setupSensTab()
        selectTab(0)

        if (savedInstanceState == null && !Settings.canDrawOverlays(this)) {
            askOverlayPermission()
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        refreshSaved()
    }

    // ---------------------------------------------------------------- ABAS
    private fun selectTab(i: Int) {
        aimTab.visibility = if (i == 0) View.VISIBLE else View.GONE
        sensTab.visibility = if (i == 1) View.VISIBLE else View.GONE
        tabAim.setBackgroundResource(if (i == 0) R.drawable.bg_button else 0)
        tabSens.setBackgroundResource(if (i == 1) R.drawable.bg_button else 0)
        if (i == 0) currentFocus?.clearFocus()
    }

    // ---------------------------------------------------------------- CONFIGURAÇÕES
    private fun showSettings() {
        val c = this
        val root = Ui.vBox(c).apply {
            setBackgroundResource(R.drawable.bg_panel)
            setPadding(Ui.dp(c, 20), Ui.dp(c, 20), Ui.dp(c, 20), Ui.dp(c, 16))
        }
        root.addView(Ui.text(c, getString(R.string.settings_title), 13f, Ui.CYAN, true))

        root.addView(Ui.text(c, getString(R.string.language), 11f, Ui.MUTED, true), Ui.lp(top = Ui.dp(c, 16)))
        val current = prefs.lang
        LANGUAGES.forEach { (code, label) ->
            val name = if (code.isEmpty()) "$label ${getString(R.string.lang_system)}" else label
            val chip = Ui.chip(c, name, code == current, 13f).apply {
                gravity = android.view.Gravity.START or android.view.Gravity.CENTER_VERTICAL
                setPadding(Ui.dp(c, 14), Ui.dp(c, 12), Ui.dp(c, 14), Ui.dp(c, 12))
            }
            root.addView(chip, LinearLayout.LayoutParams(-1, -2).apply { topMargin = Ui.dp(c, 6) })
            chip.setOnClickListener {
                if (code != prefs.lang) changeLanguage(code)
            }
        }

        root.addView(Ui.text(c, getString(R.string.follow), 11f, Ui.MUTED, true), Ui.lp(top = Ui.dp(c, 18)))
        val insta = Ui.button(c, "📸  INSTAGRAM  ·  @x_mlk_vini")
        val tiktok = Ui.button(c, "🎵  TIKTOK  ·  @vgking7x")
        insta.setOnClickListener { openLink(INSTAGRAM) }
        tiktok.setOnClickListener { openLink(TIKTOK) }
        root.addView(insta, Ui.lp(top = Ui.dp(c, 8)))
        root.addView(tiktok, Ui.lp(top = Ui.dp(c, 8)))

        val version = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: "1.0"
        } catch (e: Exception) { "1.0" }
        root.addView(Ui.text(c, getString(R.string.version_fmt, version), 10f, Ui.MUTED).apply {
            gravity = android.view.Gravity.CENTER
        }, Ui.lp(top = Ui.dp(c, 16)))

        val close = Ui.button(c, getString(R.string.close), danger = true)
        root.addView(close, Ui.lp(top = Ui.dp(c, 12)))

        val dialog = AlertDialog.Builder(c).setView(ScrollView(c).apply { addView(root) }).create()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        close.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun changeLanguage(code: String) {
        prefs.lang = code
        // reinicia o painel flutuante para ele também trocar de idioma
        if (OverlayService.running) {
            stopService(Intent(this, OverlayService::class.java))
            OverlayService.running = false
            if (Settings.canDrawOverlays(this)) {
                ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
            }
        }
        recreate()
    }

    private fun openLink(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            Toast.makeText(this, url, Toast.LENGTH_LONG).show()
        }
    }

    // ---------------------------------------------------------------- PERMISSÕES
    private fun askOverlayPermission() {
        neonDialog(getString(R.string.perm_needed), getString(R.string.perm_msg), getString(R.string.allow)) {
            openOverlaySettings()
        }
    }

    private fun openOverlaySettings() {
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
        }
    }

    private fun ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
    }

    private fun refreshStatus() {
        val ok = Settings.canDrawOverlays(this)
        txtOverlay.setText(if (ok) R.string.overlay_on else R.string.overlay_off)
        txtOverlay.setTextColor(if (ok) Ui.LIME else Ui.DANGER)
        btnGrant.visibility = if (ok) View.GONE else View.VISIBLE
        val running = OverlayService.running
        btnToggle.setText(if (running) R.string.stop_panel else R.string.start_panel)
        btnToggle.setBackgroundResource(if (running) R.drawable.bg_button_off else R.drawable.bg_button)
    }

    private fun startOverlay() {
        ensureNotificationPermission()
        ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
    }

    // ---------------------------------------------------------------- ABA MIRA
    private fun setupAimTab() {
        preview = findViewById(R.id.preview)
        btnToggle = findViewById(R.id.btnToggle)
        txtOverlay = findViewById(R.id.txtOverlayStatus)
        btnGrant = findViewById(R.id.btnGrant)
        btnGrant.setOnClickListener { openOverlaySettings() }
        findViewById<TextView>(R.id.btnPlay).setOnClickListener { playFreeFire() }

        btnToggle.setOnClickListener {
            if (OverlayService.running) {
                stopService(Intent(this, OverlayService::class.java))
                OverlayService.running = false
                btnToggle.postDelayed({ refreshStatus() }, 300)
            } else {
                if (!Settings.canDrawOverlays(this)) { askOverlayPermission(); return@setOnClickListener }
                startOverlay()
                Toast.makeText(this, R.string.panel_started, Toast.LENGTH_SHORT).show()
                btnToggle.postDelayed({ refreshStatus() }, 400)
            }
        }

        val seekSize = findViewById<SeekBar>(R.id.seekSize)
        val seekThick = findViewById<SeekBar>(R.id.seekThick)
        val seekAlpha = findViewById<SeekBar>(R.id.seekAlpha)
        val lblSize = findViewById<TextView>(R.id.lblSize)
        val lblThick = findViewById<TextView>(R.id.lblThick)
        val lblAlpha = findViewById<TextView>(R.id.lblAlpha)
        val swGlow = findViewById<MaterialSwitch>(R.id.swGlow)

        seekSize.progress = prefs.size - 10
        seekThick.progress = prefs.thick - 1
        seekAlpha.progress = prefs.alpha - 20
        swGlow.isChecked = prefs.glow

        fun labels() {
            lblSize.text = getString(R.string.size_fmt, prefs.size)
            lblThick.text = getString(R.string.thick_fmt, prefs.thick)
            lblAlpha.text = getString(R.string.alpha_fmt, prefs.alpha)
        }
        labels()

        val listener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, v: Int, fromUser: Boolean) {
                if (!fromUser) return
                when (s.id) {
                    R.id.seekSize -> prefs.size = v + 10
                    R.id.seekThick -> prefs.thick = v + 1
                    R.id.seekAlpha -> prefs.alpha = v + 20
                }
                labels(); updatePreview()
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        }
        seekSize.setOnSeekBarChangeListener(listener)
        seekThick.setOnSeekBarChangeListener(listener)
        seekAlpha.setOnSeekBarChangeListener(listener)
        swGlow.setOnCheckedChangeListener { _, b -> prefs.glow = b; updatePreview() }

        buildStyleRow()
        buildColorRow()
        updatePreview()
    }

    private fun buildStyleRow() {
        val row = findViewById<LinearLayout>(R.id.styleRow)
        row.removeAllViews()
        Catalog.styleNames(this).forEachIndexed { i, name ->
            row.addView(Ui.chip(this, name, i == prefs.style).apply {
                setOnClickListener { prefs.style = i; buildStyleRow(); updatePreview() }
            })
        }
    }

    private fun buildColorRow() {
        val row = findViewById<LinearLayout>(R.id.colorRow)
        row.removeAllViews()
        Catalog.colors.forEach { col ->
            row.addView(Ui.colorDot(this, col, col == prefs.color).apply {
                setOnClickListener { prefs.color = col; buildColorRow(); updatePreview() }
            })
        }
    }

    private fun updatePreview() {
        preview.load(prefs)
        findViewById<TextView>(R.id.txtStyleName).text =
            Catalog.styleNames(this).getOrElse(prefs.style) { "" }.uppercase()
    }

    // ---------------------------------------------------------------- JOGAR FREE FIRE
    private val ffPackages = listOf(
        "com.dts.freefireth" to "Free Fire",
        "com.dts.freefiremax" to "Free Fire MAX"
    )

    private fun playFreeFire() {
        val installed = ffPackages.filter { packageManager.getLaunchIntentForPackage(it.first) != null }
        when {
            installed.isEmpty() -> neonDialog(
                getString(R.string.ff_not_found), getString(R.string.ff_not_found_msg), getString(R.string.play_store)
            ) {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.dts.freefireth")))
                } catch (e: Exception) {
                    openLink("https://play.google.com/store/apps/details?id=com.dts.freefireth")
                }
            }
            installed.size == 1 -> launchGame(installed[0].first)
            else -> AlertDialog.Builder(this)
                .setTitle(R.string.which_version)
                .setItems(installed.map { it.second }.toTypedArray()) { _, w -> launchGame(installed[w].first) }
                .show()
        }
    }

    private fun launchGame(pkg: String) {
        if (Settings.canDrawOverlays(this) && !OverlayService.running) startOverlay()
        val intent = packageManager.getLaunchIntentForPackage(pkg) ?: return
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        Toast.makeText(this, R.string.opening, Toast.LENGTH_SHORT).show()
        startActivity(intent)
    }

    // ---------------------------------------------------------------- ABA SENSIBILIDADE
    private fun setupSensTab() {
        val recycler = findViewById<RecyclerView>(R.id.recycler)
        val search = findViewById<EditText>(R.id.search)
        val count = findViewById<TextView>(R.id.txtCount)
        adapter = PhoneAdapter { showResult(SensitivityCalculator.calc(this, it)) }
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        fun update() {
            val list = PhoneDb.search(this, search.text.toString(), brandFilter)
            adapter.submit(list)
            val total = PhoneDb.all(this).size
            count.text = if (list.isEmpty()) getString(R.string.count_none)
            else getString(R.string.count_fmt, list.size, total)
        }

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = update()
        })

        val brands = listOf<String?>(null) + PhoneDb.all(this).map { it.brand }.distinct()
        val brandRow = findViewById<LinearLayout>(R.id.brandRow)
        fun buildBrands() {
            brandRow.removeAllViews()
            brands.forEach { b ->
                brandRow.addView(Ui.chip(this, b ?: getString(R.string.all_brands), b == brandFilter).apply {
                    setOnClickListener { brandFilter = b; buildBrands(); update() }
                })
            }
        }
        buildBrands()
        findViewById<TextView>(R.id.btnManual).setOnClickListener { showManual() }
        update()
    }

    private fun refreshSaved() {
        val t = findViewById<TextView>(R.id.txtSaved)
        val s = SensResult.fromJson(prefs.sensJson)
        if (s == null) { t.visibility = View.GONE; return }
        t.visibility = View.VISIBLE
        t.text = getString(R.string.saved_fmt, s.title, s.geral, s.redDot, s.x2, s.x4)
        t.setOnClickListener { showResult(s) }
    }

    private fun showResult(r: SensResult) {
        val c = this
        val root = Ui.vBox(c).apply {
            setBackgroundResource(R.drawable.bg_panel)
            setPadding(Ui.dp(c, 20), Ui.dp(c, 20), Ui.dp(c, 20), Ui.dp(c, 16))
        }
        root.addView(Ui.text(c, getString(R.string.sens_generated), 11f, Ui.MAGENTA, true))
        root.addView(Ui.text(c, r.title, 18f, Ui.CYAN, true), Ui.lp(top = Ui.dp(c, 6)))
        root.addView(Ui.text(c, r.specs, 11f, Ui.MUTED), Ui.lp(top = Ui.dp(c, 2)))

        val bars = Ui.vBox(c)
        bars.addView(Ui.sensBar(c, getString(R.string.s_general), r.geral))
        bars.addView(Ui.sensBar(c, getString(R.string.s_reddot), r.redDot))
        bars.addView(Ui.sensBar(c, getString(R.string.s_2x), r.x2))
        bars.addView(Ui.sensBar(c, getString(R.string.s_4x), r.x4))
        bars.addView(Ui.sensBar(c, getString(R.string.s_awm), r.awm))
        bars.addView(Ui.sensBar(c, getString(R.string.s_freelook), r.olhadinha))
        root.addView(bars, Ui.lp(top = Ui.dp(c, 12)))

        val extra = buildString {
            if (r.dpi != null) append(getString(R.string.dpi_fmt, r.dpi)).append("\n")
            append(getString(R.string.fire_fmt, r.fireButton)).append("\n")
            append(getString(R.string.gfx_fmt, r.graphics, r.fps))
        }
        root.addView(Ui.text(c, extra, 12f, Ui.TEXT).apply {
            setBackgroundResource(R.drawable.bg_chip)
            setPadding(Ui.dp(c, 12), Ui.dp(c, 10), Ui.dp(c, 12), Ui.dp(c, 10))
            setLineSpacing(0f, 1.3f)
        }, Ui.lp(top = Ui.dp(c, 12)))
        if (r.dpi != null) {
            root.addView(Ui.text(c, getString(R.string.dpi_note), 10f, Ui.MUTED), Ui.lp(top = Ui.dp(c, 6)))
        }

        val row = Ui.hRow(c)
        val btnSave = Ui.button(c, getString(R.string.save_panel))
        val btnCopy = Ui.button(c, getString(R.string.copy))
        row.addView(btnSave, LinearLayout.LayoutParams(0, -2, 1.4f))
        row.addView(View(c), LinearLayout.LayoutParams(Ui.dp(c, 10), 1))
        row.addView(btnCopy, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row, Ui.lp(top = Ui.dp(c, 14)))

        val dialog = AlertDialog.Builder(c).setView(ScrollView(c).apply { addView(root) }).create()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        btnSave.setOnClickListener {
            prefs.sensJson = r.toJson()
            refreshSaved()
            Toast.makeText(c, R.string.saved_toast, Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }
        btnCopy.setOnClickListener {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("sens", r.asText(c)))
            Toast.makeText(c, R.string.copied_toast, Toast.LENGTH_SHORT).show()
        }
        dialog.show()
    }

    private fun showManual() {
        val c = this
        var inch = 6.5
        var hz = 90
        var tier = 2
        val root = Ui.vBox(c).apply {
            setBackgroundResource(R.drawable.bg_panel)
            setPadding(Ui.dp(c, 20), Ui.dp(c, 20), Ui.dp(c, 20), Ui.dp(c, 16))
        }
        root.addView(Ui.text(c, getString(R.string.manual_title), 11f, Ui.MAGENTA, true))
        root.addView(Ui.text(c, getString(R.string.manual_desc), 12f, Ui.TEXT), Ui.lp(top = Ui.dp(c, 6)))

        val name = EditText(c).apply {
            hint = getString(R.string.manual_name_hint); setTextColor(Ui.TEXT); setHintTextColor(Ui.MUTED)
            textSize = 13f; setBackgroundResource(R.drawable.bg_input)
            setPadding(Ui.dp(c, 14), Ui.dp(c, 10), Ui.dp(c, 14), Ui.dp(c, 10))
        }
        root.addView(name, Ui.lp(top = Ui.dp(c, 12)))

        val lblInch = Ui.text(c, "", 12f, Ui.MUTED)
        root.addView(lblInch, Ui.lp(top = Ui.dp(c, 14)))
        val seek = SeekBar(c).apply { max = 30; progress = 15 }
        fun lbl() { lblInch.text = getString(R.string.screen_fmt, SensitivityCalculator.fmtInch(inch)) }
        lbl()
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, v: Int, f: Boolean) { inch = 5.0 + v / 10.0; lbl() }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        root.addView(seek, Ui.lp())

        root.addView(Ui.text(c, getString(R.string.refresh_rate), 12f, Ui.MUTED), Ui.lp(top = Ui.dp(c, 12)))
        val hzRow = Ui.hRow(c)
        fun buildHz() {
            hzRow.removeAllViews()
            listOf(60, 90, 120, 144).forEach { h ->
                hzRow.addView(Ui.chip(c, "${h}Hz", h == hz).apply { setOnClickListener { hz = h; buildHz() } })
            }
        }
        buildHz()
        root.addView(hzRow, Ui.lp(top = Ui.dp(c, 6)))

        root.addView(Ui.text(c, getString(R.string.performance), 12f, Ui.MUTED), Ui.lp(top = Ui.dp(c, 12)))
        val tierBox = Ui.vBox(c)
        fun buildTier() {
            tierBox.removeAllViews()
            val r1 = Ui.hRow(c); val r2 = Ui.hRow(c)
            for (t in 1..4) {
                val chip = Ui.chip(c, Catalog.tierName(c, t), t == tier).apply { setOnClickListener { tier = t; buildTier() } }
                if (t <= 2) r1.addView(chip) else r2.addView(chip)
            }
            tierBox.addView(r1); tierBox.addView(r2, Ui.lp(top = Ui.dp(c, 6)))
        }
        buildTier()
        root.addView(tierBox, Ui.lp(top = Ui.dp(c, 6)))

        val gen = Ui.button(c, getString(R.string.generate))
        root.addView(gen, Ui.lp(top = Ui.dp(c, 16)))

        val dialog = AlertDialog.Builder(c).setView(ScrollView(c).apply { addView(root) }).create()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        gen.setOnClickListener {
            val title = name.text.toString().trim().ifEmpty { getString(R.string.custom_phone) }
            val specs = "${SensitivityCalculator.fmtInch(inch)}\" · ${hz}Hz · ${Catalog.tierName(c, tier)}"
            dialog.dismiss()
            showResult(SensitivityCalculator.calc(c, title, tier, hz, inch, 2022, false, specs))
        }
        dialog.show()
    }

    private fun neonDialog(title: String, msg: String, action: String, onOk: () -> Unit) {
        val c = this
        val root = Ui.vBox(c).apply {
            setBackgroundResource(R.drawable.bg_panel)
            setPadding(Ui.dp(c, 22), Ui.dp(c, 22), Ui.dp(c, 22), Ui.dp(c, 18))
        }
        root.addView(Ui.text(c, "⚠ $title", 15f, Ui.CYAN, true))
        root.addView(Ui.text(c, msg, 13f, Ui.TEXT).apply { setLineSpacing(0f, 1.3f) }, Ui.lp(top = Ui.dp(c, 12)))
        val row = Ui.hRow(c)
        val later = Ui.button(c, getString(R.string.later), danger = true)
        val ok = Ui.button(c, action)
        row.addView(later, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(View(c), LinearLayout.LayoutParams(Ui.dp(c, 10), 1))
        row.addView(ok, LinearLayout.LayoutParams(0, -2, 1.3f))
        root.addView(row, Ui.lp(top = Ui.dp(c, 18)))
        val d = AlertDialog.Builder(c).setView(root).create()
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        later.setOnClickListener { d.dismiss() }
        ok.setOnClickListener { d.dismiss(); onOk() }
        d.show()
    }
}

class PhoneAdapter(private val onClick: (Phone) -> Unit) : RecyclerView.Adapter<PhoneAdapter.VH>() {
    private var items: List<Phone> = emptyList()

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tier: TextView = v.findViewById(R.id.tier)
        val name: TextView = v.findViewById(R.id.name)
        val specs: TextView = v.findViewById(R.id.specs)
    }

    @SuppressLint("NotifyDataSetChanged")
    fun submit(list: List<Phone>) { items = list; notifyDataSetChanged() }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_phone, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, pos: Int) {
        val p = items[pos]
        h.name.text = p.fullName
        h.specs.text = SensitivityCalculator.specs(h.itemView.context, p)
        h.tier.text = when (p.tier) { 1 -> "B"; 2 -> "I"; 3 -> "A"; else -> "T" }
        h.tier.setTextColor(when (p.tier) { 1 -> Ui.MUTED; 2 -> Ui.CYAN; 3 -> Ui.MAGENTA; else -> Ui.LIME })
        h.itemView.setOnClickListener { onClick(p) }
    }
}
