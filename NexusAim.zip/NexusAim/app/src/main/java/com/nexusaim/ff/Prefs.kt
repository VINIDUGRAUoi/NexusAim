package com.nexusaim.ff

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color

class Prefs(ctx: Context) {
    val sp: SharedPreferences = ctx.getSharedPreferences("nexus", Context.MODE_PRIVATE)

    var crossOn: Boolean
        get() = sp.getBoolean("crossOn", true)
        set(v) = sp.edit().putBoolean("crossOn", v).apply()
    var style: Int
        get() = sp.getInt("style", 3)
        set(v) = sp.edit().putInt("style", v).apply()
    var color: Int
        get() = sp.getInt("color", Color.parseColor("#FF2D2D"))
        set(v) = sp.edit().putInt("color", v).apply()
    var size: Int
        get() = sp.getInt("size", 36)
        set(v) = sp.edit().putInt("size", v.coerceIn(10, 100)).apply()
    var thick: Int
        get() = sp.getInt("thick", 2)
        set(v) = sp.edit().putInt("thick", v.coerceIn(1, 8)).apply()
    var alpha: Int
        get() = sp.getInt("alpha", 100)
        set(v) = sp.edit().putInt("alpha", v.coerceIn(20, 100)).apply()
    var glow: Boolean
        get() = sp.getBoolean("glow", true)
        set(v) = sp.edit().putBoolean("glow", v).apply()
    var offX: Int
        get() = sp.getInt("offX", 0)
        set(v) = sp.edit().putInt("offX", v.coerceIn(-300, 300)).apply()
    var offY: Int
        get() = sp.getInt("offY", 0)
        set(v) = sp.edit().putInt("offY", v.coerceIn(-300, 300)).apply()
    var filter: Int
        get() = sp.getInt("filter", 0)
        set(v) = sp.edit().putInt("filter", v).apply()
    var sensJson: String
        get() = sp.getString("sens", "") ?: ""
        set(v) = sp.edit().putString("sens", v).apply()

    fun applyPreset(p: Preset) {
        sp.edit()
            .putInt("style", p.style).putInt("color", p.color).putInt("size", p.size)
            .putInt("thick", p.thick).putInt("alpha", p.alpha).putBoolean("glow", p.glow)
            .putBoolean("crossOn", true).apply()
    }
}

data class Preset(
    val name: String, val desc: String, val style: Int, val color: Int,
    val size: Int, val thick: Int, val alpha: Int, val glow: Boolean
)

object Catalog {
    val styleNames = listOf(
        "Cruz", "Ponto", "Círculo", "Cruz + Ponto", "T Tático", "Sniper", "X Diagonal", "Anel Segmentado"
    )
    val colors = listOf(
        "#FF2D2D", "#39FF14", "#00F0FF", "#FF2BD6", "#FFE600", "#FFFFFF", "#FF8A00", "#9D4DFF"
    ).map { Color.parseColor(it) }

    val presets = listOf(
        Preset("PRECISÃO", "Ponto pequeno para tiros na cabeça a média distância", 1, colors[0], 18, 3, 100, true),
        Preset("RUSH", "Mira maior e visível para trocação de perto", 3, colors[1], 46, 2, 100, true),
        Preset("SNIPER", "Retícula de longo alcance para AWM / M82B", 5, colors[2], 72, 1, 95, true),
        Preset("TÁTICO", "T aberto que não cobre o inimigo", 4, colors[4], 36, 2, 100, true),
        Preset("ALTO CONTRASTE", "Visível em qualquer mapa e iluminação", 0, colors[3], 42, 3, 100, true),
        Preset("MINIMAL", "Discreto, sem poluir a tela", 2, colors[5], 26, 1, 70, false)
    )

    val filters = listOf(
        "Desligado" to 0x00000000,
        "Quente (realça inimigos)" to 0x66FFB000,
        "Frio (nitidez)" to 0x5500C8FF,
        "Vibrante" to 0x55FF2BD6,
        "Escurecer (noite)" to 0x99000000.toInt()
    )

    val tierNames = listOf("", "Básico", "Intermediário", "Avançado", "Topo de linha")
}
