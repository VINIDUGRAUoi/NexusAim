package com.nexusaim.ff

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color

class Prefs(ctx: Context) {
    val sp: SharedPreferences = ctx.getSharedPreferences("nexus", Context.MODE_PRIVATE)

    var crossOn: Boolean
        get() = sp.getBoolean("crossOn", true)
        set(v) = sp.edit().putBoolean("crossOn", v).apply()
    var style: Int
        get() = sp.getInt("style", 3)
        set(v) = sp.edit().putInt("style", v).apply()
    var color: Int
        get() = sp.getInt("color", Color.parseColor("#FF2D2D"))
        set(v) = sp.edit().putInt("color", v).apply()
    var size: Int
        get() = sp.getInt("size", 36)
        set(v) = sp.edit().putInt("size", v.coerceIn(10, 100)).apply()
    var thick: Int
        get() = sp.getInt("thick", 2)
        set(v) = sp.edit().putInt("thick", v.coerceIn(1, 8)).apply()
    var alpha: Int
        get() = sp.getInt("alpha", 100)
        set(v) = sp.edit().putInt("alpha", v.coerceIn(20, 100)).apply()
    var glow: Boolean
        get() = sp.getBoolean("glow", true)
        set(v) = sp.edit().putBoolean("glow", v).apply()
    var offX: Int
        get() = sp.getInt("offX", 0)
        set(v) = sp.edit().putInt("offX", v.coerceIn(-300, 300)).apply()
    var offY: Int
        get() = sp.getInt("offY", 0)
        set(v) = sp.edit().putInt("offY", v.coerceIn(-300, 300)).apply()
    var filter: Int
        get() = sp.getInt("filter", 0)
        set(v) = sp.edit().putInt("filter", v).apply()
    var lang: String
        get() = sp.getString("lang", "") ?: ""
        set(v) = sp.edit().putString("lang", v).commit().let { }
    var sensJson: String
        get() = sp.getString("sens", "") ?: ""
        set(v) = sp.edit().putString("sens", v).apply()

    fun applyPreset(p: Preset) {
        sp.edit()
            .putInt("style", p.style).putInt("color", p.color).putInt("size", p.size)
            .putInt("thick", p.thick).putInt("alpha", p.alpha).putBoolean("glow", p.glow)
            .putBoolean("crossOn", true).apply()
    }
}

data class Preset(
    val style: Int, val color: Int, val size: Int, val thick: Int, val alpha: Int, val glow: Boolean
)

object Catalog {
    val colors = listOf(
        "#FF2D2D", "#39FF14", "#00F0FF", "#FF2BD6", "#FFE600", "#FFFFFF", "#FF8A00", "#9D4DFF"
    ).map { Color.parseColor(it) }

    val presets = listOf(
        Preset(1, colors[0], 18, 3, 100, true),
        Preset(3, colors[1], 46, 2, 100, true),
        Preset(5, colors[2], 72, 1, 95, true),
        Preset(4, colors[4], 36, 2, 100, true),
        Preset(0, colors[3], 42, 3, 100, true),
        Preset(2, colors[5], 26, 1, 70, false)
    )

    val filterColors = listOf(0x00000000, 0x66FFB000, 0x5500C8FF, 0x55FF2BD6, 0x99000000.toInt())

    fun styleNames(c: Context): Array<String> = c.resources.getStringArray(R.array.styles)
    fun presetName(c: Context, i: Int): String = c.resources.getStringArray(R.array.preset_names)[i]
    fun presetDesc(c: Context, i: Int): String = c.resources.getStringArray(R.array.preset_desc)[i]
    fun filterNames(c: Context): Array<String> = c.resources.getStringArray(R.array.filters)
    fun tierName(c: Context, t: Int): String = c.resources.getStringArray(R.array.tiers).getOrElse(t) { "" }
}

/** Aplica o idioma escolhido nas configurações (vazio = idioma do sistema). */
object LocaleHelper {
    fun wrap(base: Context): Context {
        val lang = base.getSharedPreferences("nexus", Context.MODE_PRIVATE).getString("lang", "") ?: ""
        if (lang.isEmpty()) return base
        val locale = java.util.Locale(lang)
        java.util.Locale.setDefault(locale)
        val conf = android.content.res.Configuration(base.resources.configuration)
        conf.setLocale(locale)
        return base.createConfigurationContext(conf)
    }
}
