package com.nexusaim.ff

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/**
 * Treino de capa: arraste a tela (como no Free Fire) para levar a mira
 * até a cabeça do alvo e toque em ATIRAR. Mede se o "puxão" passa do
 * alvo ou fica curto para calibrar a sensibilidade.
 */
class AimTrainerView @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : View(ctx, attrs) {

    data class Result(
        val heads: Int, val bodies: Int, val misses: Int,
        val avgMs: Long, val flickRatio: Float, val samples: Int
    ) {
        val total get() = heads + bodies
        val headPct get() = if (heads + bodies + misses == 0) 0 else heads * 100 / (heads + bodies + misses)
        /** Fator sugerido para multiplicar a sensibilidade. */
        val factor: Float get() = if (samples < 3) 1f else (1f / flickRatio).coerceIn(0.85f, 1.15f)
    }

    interface Listener {
        fun onUpdate(target: Int, total: Int, heads: Int, misses: Int)
        fun onFinished(r: Result)
    }

    var listener: Listener? = null
    var sensFactor = 1.1f
    val totalTargets = 10

    private val d = resources.displayMetrics.density
    private var running = false

    // câmera (posição da mira no "mundo") e alvo
    private var ox = 0f; private var oy = 0f
    private var baseX = 0f; private var baseY = 0f
    private var tx = 0f; private var ty = 0f
    private var startOx = 0f; private var startOy = 0f
    private var d0x = 0f; private var d0y = 0f
    private var flickDone = false
    private var spawnTime = 0L
    private var phase = 0f

    private var targetIdx = 0
    private var heads = 0; private var bodies = 0; private var misses = 0
    private var totalMs = 0L
    private val flicks = ArrayList<Float>()

    private var lastX = 0f; private var lastY = 0f
    private var flashText = ""; private var flashColor = Ui.LIME; private var flashUntil = 0L

    private val grid = Paint().apply { color = 0x2200F0FF; strokeWidth = 1f }
    private val body = Paint(Paint.ANTI_ALIAS_FLAG)
    private val head = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER; isFakeBoldText = true
    }
    private val rect = RectF()

    private val headR get() = 11 * d

    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

    fun start() {
        heads = 0; bodies = 0; misses = 0; totalMs = 0; targetIdx = 0
        flicks.clear(); ox = 0f; oy = 0f
        running = true
        spawn()
        invalidate()
    }

    fun stop() { running = false; invalidate() }

    private fun spawn() {
        val minSide = minOf(width, height).toFloat().coerceAtLeast(300f)
        val dist = minSide * (0.22f + Math.random().toFloat() * 0.2f)
        val ang = (Math.random() * Math.PI * 2).toFloat()
        baseX = ox + dist * cos(ang)
        baseY = oy + dist * sin(ang) * 0.8f
        startOx = ox; startOy = oy
        d0x = baseX - ox; d0y = baseY - oy
        flickDone = false
        phase = (Math.random() * 6.28).toFloat()
        spawnTime = SystemClock.uptimeMillis()
        listener?.onUpdate(targetIdx + 1, totalTargets, heads, misses)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!running) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lastX = e.x; lastY = e.y }
            MotionEvent.ACTION_MOVE -> {
                ox += (e.x - lastX) * sensFactor
                oy += (e.y - lastY) * sensFactor
                lastX = e.x; lastY = e.y
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> recordFlick()
        }
        return true
    }

    /** Primeiro puxão de cada alvo: >1 passou do alvo, <1 ficou curto. */
    private fun recordFlick() {
        if (flickDone) return
        val mx = ox - startOx; val my = oy - startOy
        val len0 = d0x * d0x + d0y * d0y
        if (len0 < 1f || hypot(mx, my) < 15 * d) return
        flickDone = true
        val progress = (mx * d0x + my * d0y) / len0
        if (progress in 0.3f..2.5f) flicks.add(progress)
    }

    fun fire() {
        if (!running) return
        recordFlick()
        val hr = headR
        val distHead = hypot(ox - tx, oy - ty)
        val inBody = ox in (tx - 15 * d)..(tx + 15 * d) && oy in (ty + hr + 2 * d)..(ty + hr + 64 * d)
        val now = SystemClock.uptimeMillis()
        when {
            distHead <= hr * 1.1f -> { heads++; flash("CAPA!", Ui.LIME); next(now) }
            inBody -> { bodies++; flash("CORPO", Ui.CYAN); next(now) }
            else -> { misses++; flash("ERROU", Ui.DANGER) }
        }
        listener?.onUpdate(targetIdx + 1, totalTargets, heads, misses)
        invalidate()
    }

    private fun next(now: Long) {
        totalMs += now - spawnTime
        targetIdx++
        if (targetIdx >= totalTargets) {
            running = false
            val sorted = flicks.sorted()
            val median = if (sorted.isEmpty()) 1f else sorted[sorted.size / 2]
            val r = Result(heads, bodies, misses, totalMs / totalTargets, median, sorted.size)
            post { listener?.onFinished(r) }
        } else spawn()
    }

    private fun flash(s: String, c: Int) {
        flashText = s; flashColor = c; flashUntil = SystemClock.uptimeMillis() + 450
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val cx = width / 2f; val cy = height / 2f

        // grade que se move com a câmera (sensação de movimento)
        val step = 40 * d
        var gx = ((-ox) % step + step) % step
        while (gx < width) { c.drawLine(gx, 0f, gx, height.toFloat(), grid); gx += step }
        var gy = ((-oy) % step + step) % step
        while (gy < height) { c.drawLine(0f, gy, width.toFloat(), gy, grid); gy += step }

        if (running) {
            // alvo se mexe de lado (strafe), como um inimigo real
            val t = (SystemClock.uptimeMillis() - spawnTime) / 1000f
            tx = baseX + sin(t * 2.2f + phase) * 22 * d
            ty = baseY
            val sx = tx - ox + cx; val sy = ty - oy + cy
            val hr = headR

            body.color = Ui.MAGENTA; body.alpha = 170
            body.setShadowLayer(12 * d, 0f, 0f, Ui.MAGENTA)
            rect.set(sx - 15 * d, sy + hr + 2 * d, sx + 15 * d, sy + hr + 64 * d)
            c.drawRoundRect(rect, 10 * d, 10 * d, body)

            head.color = Ui.TEXT
            head.setShadowLayer(14 * d, 0f, 0f, Ui.MAGENTA)
            c.drawCircle(sx, sy, hr, head)
            ring.color = Ui.LIME; ring.strokeWidth = 1.5f * d; ring.alpha = 160
            c.drawCircle(sx, sy, hr + 5 * d, ring)

            // indicador de direção quando o alvo está fora da tela
            if (sx < 0 || sx > width || sy < 0 || sy > height) {
                val ang = Math.atan2((sy - cy).toDouble(), (sx - cx).toDouble())
                val rr = minOf(width, height) * 0.42f
                txt.color = Ui.MAGENTA; txt.textSize = 22 * d
                c.drawText("◆", cx + (rr * cos(ang)).toFloat(), cy + (rr * sin(ang)).toFloat() + 8 * d, txt)
            }
            postInvalidateOnAnimation()
        }

        if (SystemClock.uptimeMillis() < flashUntil) {
            txt.color = flashColor; txt.textSize = 20 * d
            c.drawText(flashText, cx, cy - 46 * d, txt)
            postInvalidateOnAnimation()
        }
    }
}
