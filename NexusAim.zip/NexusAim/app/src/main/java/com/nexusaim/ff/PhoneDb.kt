package com.nexusaim.ff

import android.content.Context
import org.json.JSONArray
import java.text.Normalizer

data class Phone(
    val brand: String, val name: String, val year: Int,
    val tier: Int, val hz: Int, val inch: Double
) {
    val isApple get() = brand == "Apple"
    val fullName get() = if (isApple || name.startsWith(brand, ignoreCase = true)) name else "$brand $name"
    private val norm = PhoneDb.normalize("$brand $name $year")
    private val compact = norm.replace(" ", "")

    fun matches(tokens: List<String>, compactQuery: String): Boolean {
        if (tokens.isEmpty()) return true
        if (compact.contains(compactQuery)) return true
        return tokens.all { norm.contains(it) || compact.contains(it) }
    }
}

object PhoneDb {
    private var cache: List<Phone>? = null

    fun normalize(s: String): String {
        val n = Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD)
        return n.replace(Regex("\\p{Mn}+"), "").replace("+", " plus ").replace(Regex("\\s+"), " ").trim()
    }

    fun all(ctx: Context): List<Phone> {
        cache?.let { return it }
        val txt = ctx.assets.open("phones.json").bufferedReader().use { it.readText() }
        val arr = JSONArray(txt)
        val list = ArrayList<Phone>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(
                Phone(o.getString("b"), o.getString("n"), o.getInt("y"),
                    o.getInt("t"), o.getInt("hz"), o.getDouble("in"))
            )
        }
        cache = list
        return list
    }

    fun search(ctx: Context, query: String, brand: String?): List<Phone> {
        val q = normalize(query)
        val tokens = q.split(" ").filter { it.isNotBlank() }
        val compactQ = q.replace(" ", "")
        return all(ctx).filter { (brand == null || it.brand == brand) && it.matches(tokens, compactQ) }
    }
}
