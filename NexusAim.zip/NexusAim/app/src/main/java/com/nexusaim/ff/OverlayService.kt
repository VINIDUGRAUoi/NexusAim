package com.nexusaim.ff

import android.annotation.SuppressLint
import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.abs

class OverlayService : Service(), SharedPreferences.OnSharedPreferenceChangeListener {

    companion object {
        @Volatile var running = false
        private const val CHANNEL = "nexus_overlay"
        private const val ACTION_STOP = "com.nexusaim.ff.STOP"
        private val GAME_PACKAGES = setOf("com.dts.freefireth", "com.dts.freefiremax")
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private val handler = Handler(Looper.getMainLooper())

    private var crossView: CrosshairView? = null
    private var crossParams: WindowManager.LayoutParams? = null
    private var filterView: View? = null
    private var bubble: TextView? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private var panel: LinearLayout? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var content: LinearLayout? = null
    private var tabRow: LinearLayout? = null
    private var panelTab = 0
    private var monitorText: TextView? = null
    private var ramMsg = ""

    private val overlayType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = Prefs(this)
        startAsForeground()
        try {
            addBubble()
            applyFilter()
            applyCrosshair()
        } catch (e: Exception) {
            stopSelf()
            return
        }
        prefs.sp.registerOnSharedPreferenceChangeListener(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) stopSelf()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        prefs.sp.unregisterOnSharedPreferenceChangeListener(this)
        listOf<View?>(crossView, filterView, bubble, panel).forEach { v ->
            if (v != null) try { wm.removeView(v) } catch (_: Exception) {}
        }
        super.onDestroy()
    }

    override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) {
        applyCrosshair()
        applyFilter()
        if (panel != null) renderContent()
    }

    private fun dp(v: Int) = Ui.dp(this, v)

    // ---------------------------------------------------------------- NOTIFICAÇÃO
    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Painel flutuante", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val n: Notification = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Nexus Aim ativo")
            .setContentText("Mira e painel flutuante funcionando")
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "ENCERRAR", stop).build())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(7, n)
        }
    }

    // ---------------------------------------------------------------- MIRA
    /**
     * Janelas que não recebem toque precisam de alpha <= 0.8 no Android 12+,
     * senão o sistema bloqueia os toques no jogo. Mira (0.7) + filtro (0.3)
     * juntos continuam abaixo do limite.
     */
    private fun passThroughParams(w: Int, h: Int, alpha: Float) = WindowManager.LayoutParams(
        w, h, overlayType,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        this.alpha = alpha
        if (Build.VERSION.SDK_INT >= 28) {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    private fun applyCrosshair() {
        if (!prefs.crossOn) {
            crossView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            crossView = null
            return
        }
        val size = dp(220)
        if (crossView == null) {
            val v = CrosshairView(this)
            val p = passThroughParams(size, size, 0.7f).apply { gravity = Gravity.CENTER }
            crossView = v; crossParams = p
            wm.addView(v, p)
        }
        crossView?.load(prefs)
        crossParams?.let {
            it.x = dp(prefs.offX); it.y = dp(prefs.offY)
            try { wm.updateViewLayout(crossView, it) } catch (_: Exception) {}
        }
    }

    private fun applyFilter() {
        val color = Catalog.filters.getOrNull(prefs.filter)?.second ?: 0
        if (color == 0) {
            filterView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            filterView = null
            return
        }
        if (filterView == null) {
            val v = View(this)
            val p = passThroughParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, 0.3f
            )
            filterView = v
            wm.addView(v, p)
            // mantém a mira acima do filtro
            crossView?.let { cv ->
                try { wm.removeView(cv); wm.addView(cv, crossParams) } catch (_: Exception) {}
            }
        }
        filterView?.setBackgroundColor(color)
    }

    // ---------------------------------------------------------------- BOLHA
    @SuppressLint("ClickableViewAccessibility")
    private fun addBubble() {
        val b = Ui.text(this, "◎", 26f, Ui.CYAN, true).apply {
            setBackgroundResource(R.drawable.bg_bubble)
            gravity = Gravity.CENTER
            setShadowLayer(14f, 0f, 0f, Ui.CYAN)
        }
        bubbleParams = WindowManager.LayoutParams(
            dp(54), dp(54), overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(140) }

        b.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = bubbleParams.x; sy = bubbleParams.y; tx = e.rawX; ty = e.rawY; moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                        if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                        if (moved) {
                            bubbleParams.x = sx + dx; bubbleParams.y = sy + dy
                            try { wm.updateViewLayout(v, bubbleParams) } catch (_: Exception) {}
                        }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) togglePanel()
                }
                return true
            }
        })
        bubble = b
        wm.addView(b, bubbleParams)
    }

    // ---------------------------------------------------------------- PAINEL
    private fun togglePanel() {
        if (panel != null) closePanel() else openPanel()
    }

    private fun closePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null; content = null; monitorText = null
        handler.removeCallbacks(monitorTick)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun openPanel() {
        val c = this
        val root = Ui.vBox(c).apply {
            setBackgroundResource(R.drawable.bg_panel)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }

        // Cabeçalho (arrastável)
        val header = Ui.hRow(c)
        header.addView(Ui.text(c, "NEXUS//AIM", 15f, Ui.CYAN, true).apply {
            setShadowLayer(12f, 0f, 0f, Ui.CYAN)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        val btnMin = Ui.chip(c, "—", false, 13f)
        val btnOff = Ui.chip(c, "⏻", false, 13f).apply { setTextColor(Ui.DANGER) }
        header.addView(btnMin); header.addView(btnOff)
        btnMin.setOnClickListener { closePanel() }
        btnOff.setOnClickListener { stopSelf() }
        root.addView(header)
        root.addView(Ui.text(c, "▸ PAINEL TÁTICO · arraste pelo título", 9f, Ui.MAGENTA), Ui.lp(top = dp(2)))

        val tabs = Ui.hRow(c)
        tabRow = tabs
        root.addView(tabs, Ui.lp(top = dp(10)))

        val inner = Ui.vBox(c)
        content = inner
        val sv = ScrollView(c).apply { addView(inner); isVerticalScrollBarEnabled = false }
        val screenH = resources.displayMetrics.heightPixels
        val maxH = minOf(dp(330), (screenH * 0.62f).toInt())
        root.addView(sv, LinearLayout.LayoutParams(-1, maxH).apply { topMargin = dp(10) })

        val p = WindowManager.LayoutParams(
            dp(300), WindowManager.LayoutParams.WRAP_CONTENT, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        panelParams = p

        header.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = p.x; sy = p.y; tx = e.rawX; ty = e.rawY }
                    MotionEvent.ACTION_MOVE -> {
                        p.x = sx + (e.rawX - tx).toInt(); p.y = sy + (e.rawY - ty).toInt()
                        try { wm.updateViewLayout(root, p) } catch (_: Exception) {}
                    }
                }
                return true
            }
        })

        panel = root
        wm.addView(root, p)
        renderContent()
    }

    private fun renderTabs() {
        val tabs = tabRow ?: return
        tabs.removeAllViews()
        listOf("MIRA", "MODOS", "OTIMIZAR", "SENS").forEachIndexed { i, s ->
            val chip = Ui.chip(this, s, i == panelTab, 10f).apply {
                setPadding(dp(4), dp(7), dp(4), dp(7))
                setOnClickListener { panelTab = i; renderContent() }
            }
            tabs.addView(chip, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = if (i < 3) dp(4) else 0 })
        }
    }

    private fun renderContent() {
        val box = content ?: return
        renderTabs()
        box.removeAllViews()
        monitorText = null
        handler.removeCallbacks(monitorTick)
        when (panelTab) {
            0 -> renderAim(box)
            1 -> renderModes(box)
            2 -> renderOptimize(box)
            else -> renderSens(box)
        }
    }

    private fun section(box: LinearLayout, title: String) {
        box.addView(Ui.text(this, "// $title", 10f, Ui.CYAN, true), Ui.lp(top = dp(10)))
    }

    /** Linha: rótulo  [-] valor [+] */
    private fun stepper(box: LinearLayout, label: String, value: String, onMinus: () -> Unit, onPlus: () -> Unit) {
        val row = Ui.hRow(this)
        row.addView(Ui.text(this, label, 11f, Ui.TEXT), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Ui.chip(this, "−", false, 13f).apply { setOnClickListener { onMinus() } })
        row.addView(Ui.text(this, value, 12f, Ui.CYAN, true).apply {
            gravity = Gravity.CENTER; minWidth = dp(44)
        })
        row.addView(Ui.chip(this, "+", false, 13f).apply {
            setOnClickListener { onPlus() }
            (layoutParams as LinearLayout.LayoutParams).marginEnd = 0
        })
        box.addView(row, Ui.lp(top = dp(6)))
    }

    private fun renderAim(box: LinearLayout) {
        val c = this
        val toggle = Ui.button(c, if (prefs.crossOn) "◉ MIRA LIGADA" else "○ MIRA DESLIGADA", danger = !prefs.crossOn)
        toggle.setOnClickListener { prefs.crossOn = !prefs.crossOn }
        box.addView(toggle, Ui.lp())

        section(box, "ESTILO")
        val n = Catalog.styleNames.size
        stepper(box, "Formato", Catalog.styleNames[prefs.style % n].take(10),
            { prefs.style = (prefs.style - 1 + n) % n }, { prefs.style = (prefs.style + 1) % n })

        section(box, "COR")
        val colors = Ui.hRow(c)
        Catalog.colors.forEach { col ->
            colors.addView(Ui.colorDot(c, col, col == prefs.color, 24).apply {
                (layoutParams as LinearLayout.LayoutParams).marginEnd = dp(6)
                setOnClickListener { prefs.color = col }
            })
        }
        box.addView(colors, Ui.lp(top = dp(6)))

        section(box, "AJUSTES")
        stepper(box, "Tamanho", prefs.size.toString(), { prefs.size -= 4 }, { prefs.size += 4 })
        stepper(box, "Espessura", prefs.thick.toString(), { prefs.thick -= 1 }, { prefs.thick += 1 })
        stepper(box, "Opacidade", "${prefs.alpha}%", { prefs.alpha -= 10 }, { prefs.alpha += 10 })
        val glow = Ui.chip(c, if (prefs.glow) "✦ Brilho neon: ON" else "✧ Brilho neon: OFF", prefs.glow)
        glow.setOnClickListener { prefs.glow = !prefs.glow }
        box.addView(glow, Ui.lp(top = dp(8)))

        section(box, "CALIBRAR POSIÇÃO (${prefs.offX}, ${prefs.offY})")
        val pad = Ui.hRow(c).apply { gravity = Gravity.CENTER }
        fun arrow(s: String, act: () -> Unit) = Ui.chip(c, s, false, 13f).apply { setOnClickListener { act() } }
        pad.addView(arrow("◀") { prefs.offX -= 2 })
        pad.addView(arrow("▲") { prefs.offY -= 2 })
        pad.addView(arrow("●") { prefs.offX = 0; prefs.offY = 0 })
        pad.addView(arrow("▼") { prefs.offY += 2 })
        pad.addView(arrow("▶") { prefs.offX += 2 })
        box.addView(pad, Ui.lp(top = dp(6)))
        box.addView(Ui.text(c, "Ajuste se a mira não estiver no centro exato da mira do jogo (celulares com entalhe).", 9f, Ui.MUTED),
            Ui.lp(top = dp(6)))
    }

    private fun renderModes(box: LinearLayout) {
        section(box, "MODOS DE MIRA")
        Catalog.presets.forEach { pr ->
            val active = prefs.style == pr.style && prefs.color == pr.color && prefs.size == pr.size
            val card = Ui.vBox(this).apply {
                setBackgroundResource(if (active) R.drawable.bg_chip_on else R.drawable.bg_chip)
                setPadding(dp(12), dp(9), dp(12), dp(9))
                setOnClickListener { prefs.applyPreset(pr) }
            }
            val top = Ui.hRow(this)
            top.addView(Ui.colorDot(this, pr.color, false, 12).apply {
                (layoutParams as LinearLayout.LayoutParams).marginEnd = dp(8)
            })
            top.addView(Ui.text(this, pr.name, 12f, if (active) Ui.CYAN else Ui.TEXT, true))
            if (active) top.addView(Ui.text(this, "  ✔ ATIVO", 9f, Ui.LIME, true))
            card.addView(top)
            card.addView(Ui.text(this, pr.desc, 9f, Ui.MUTED), Ui.lp(top = dp(3)))
            box.addView(card, Ui.lp(top = dp(6)))
        }

        section(box, "FILTRO VISUAL DE TELA")
        Catalog.filters.forEachIndexed { i, f ->
            val chip = Ui.chip(this, f.first, prefs.filter == i).apply {
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                setOnClickListener { prefs.filter = i }
            }
            box.addView(chip, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })
        }
    }

    private fun renderOptimize(box: LinearLayout) {
        val c = this
        section(box, "MONITOR DO SISTEMA")
        val mon = Ui.text(c, "", 11f, Ui.TEXT).apply {
            setBackgroundResource(R.drawable.bg_chip)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setLineSpacing(0f, 1.3f)
        }
        box.addView(mon, Ui.lp(top = dp(6)))
        monitorText = mon
        monitorTick.run()

        section(box, "OTIMIZAÇÃO")
        val btnRam = Ui.button(c, "⚡ LIBERAR MEMÓRIA RAM")
        btnRam.setOnClickListener {
            btnRam.text = "LIBERANDO..."
            freeRam { freedMb ->
                ramMsg = if (freedMb > 0) "✔ ${freedMb} MB liberados" else "✔ Processos em segundo plano encerrados"
                renderContent()
            }
        }
        box.addView(btnRam, Ui.lp(top = dp(6)))
        if (ramMsg.isNotEmpty()) box.addView(Ui.text(c, ramMsg, 10f, Ui.LIME), Ui.lp(top = dp(4)))

        val focus = Ui.chip(c, "🎯 MODO FOCO (mira precisão + filtro quente)", false)
        focus.setOnClickListener { prefs.applyPreset(Catalog.presets[0]); prefs.filter = 1 }
        box.addView(focus, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

        val clean = Ui.chip(c, "↺ RESTAURAR PADRÕES DO PAINEL", false)
        clean.setOnClickListener {
            prefs.filter = 0; prefs.offX = 0; prefs.offY = 0; prefs.applyPreset(Catalog.presets[1])
        }
        box.addView(clean, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

        section(box, "DICAS DE DESEMPENHO")
        box.addView(Ui.text(c,
            "• Ative o modo Jogo/Game Turbo do seu celular\n" +
                "• Deixe a bateria acima de 20% e o celular fora da capa se esquentar\n" +
                "• Use gráficos e FPS sugeridos na aba SENS\n" +
                "• Ative o Não Perturbe para evitar notificações na partida",
            10f, Ui.MUTED).apply { setLineSpacing(0f, 1.25f) }, Ui.lp(top = dp(6)))
    }

    private fun renderSens(box: LinearLayout) {
        val s = SensResult.fromJson(prefs.sensJson)
        if (s == null) {
            box.addView(Ui.text(this,
                "Nenhuma sensibilidade salva.\n\nAbra o app › aba SENSIBILIDADE › pesquise seu celular › SALVAR NO PAINEL.",
                11f, Ui.MUTED).apply { setLineSpacing(0f, 1.3f) }, Ui.lp(top = dp(10)))
            return
        }
        box.addView(Ui.text(this, s.title, 13f, Ui.CYAN, true), Ui.lp(top = dp(4)))
        box.addView(Ui.text(this, s.specs, 9f, Ui.MUTED), Ui.lp(top = dp(2)))
        box.addView(Ui.sensBar(this, "Geral", s.geral), Ui.lp(top = dp(6)))
        box.addView(Ui.sensBar(this, "Ponto Vermelho", s.redDot))
        box.addView(Ui.sensBar(this, "Mira 2x", s.x2))
        box.addView(Ui.sensBar(this, "Mira 4x", s.x4))
        box.addView(Ui.sensBar(this, "Mira AWM", s.awm))
        box.addView(Ui.sensBar(this, "Olhadinha", s.olhadinha))
        val extra = (if (s.dpi != null) "DPI ${s.dpi} · " else "") + "Botão ${s.fireButton}% · ${s.graphics} · FPS ${s.fps}"
        box.addView(Ui.text(this, extra, 10f, Ui.TEXT), Ui.lp(top = dp(6)))
    }

    // ---------------------------------------------------------------- SISTEMA
    private val monitorTick = object : Runnable {
        override fun run() {
            val tv = monitorText ?: return
            val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
            val freeMb = mi.availMem / 1048576
            val totalMb = mi.totalMem / 1048576
            val usedPct = if (totalMb > 0) (100 - freeMb * 100 / totalMb) else 0
            val bat = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = bat?.let {
                val l = it.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val sc = it.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                if (l >= 0 && sc > 0) l * 100 / sc else -1
            } ?: -1
            val temp = (bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
            @Suppress("DEPRECATION")
            val hz = wm.defaultDisplay.refreshRate.toInt()
            val tempWarn = when {
                temp >= 42f -> "  ⚠ QUENTE"
                temp >= 38f -> "  ⚡ morno"
                else -> "  ✔ ok"
            }
            tv.text = "RAM livre: ${freeMb} MB / ${totalMb} MB  (${usedPct}% em uso)\n" +
                "Bateria: ${if (level >= 0) "$level%" else "--"}  ·  Temp: ${"%.1f".format(temp)}°C$tempWarn\n" +
                "Tela: ${hz}Hz"
            handler.postDelayed(this, 2000)
        }
    }

    private fun freeRam(done: (Long) -> Unit) {
        Thread {
            val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
            val before = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.availMem
            try {
                @Suppress("DEPRECATION")
                val apps = packageManager.getInstalledApplications(0)
                for (app in apps) {
                    if (app.packageName == packageName || app.packageName in GAME_PACKAGES) continue
                    if ((app.flags and ApplicationInfo.FLAG_SYSTEM) != 0) continue
                    try { am.killBackgroundProcesses(app.packageName) } catch (_: Exception) {}
                }
            } catch (_: Exception) {}
            Thread.sleep(600)
            val after = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.availMem
            val freed = ((after - before) / 1048576).coerceAtLeast(0)
            handler.post { done(freed) }
        }.start()
    }
}
